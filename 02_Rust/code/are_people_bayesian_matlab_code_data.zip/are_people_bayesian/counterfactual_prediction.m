% counterfactual_prediction.m  program to use the data from the El-Gamal and Grether experiments at
%                              the University of Wisconsin described in their paper, "Changing Decision Rules:
%                              Uncovering Behavioral Strategies Using Estimation-Classification (EC)" 1999
%                              where experiments testing the hypothesis of Bayesian decision making were run
%                              on successive days, with a first day subjects saw draws from one of two cages
%                              with n1 balls in it and on the second day the subjects saw draws from one of two
%                              cages with n2 balls in each, where for one set of subjects (n1,n2)=(6,10) and for
%                              the other (n1,n2)=(10,6).  We use the second day in each case as an "evaluation"
%                              or "testing sample" to see how different models do counterfactual predictions of
%                              how subjects react to a change in the experimental parameters.  So we estimate various
%                              reduced form and structural models using data on the first day choices and the evaluate
%                              how well these various models predict choices on the 2nd day of the experiment.
%                              John Rust, Georgetown University, August, 2023

transform_inputs=0;  % enter 1 to pre-transform the inputs to the 5 parameter Neural Network model that serves as the
                     % reduced-form model to compare with the structural logit model in its ability to make out-of-sample
                     % predictions of the subjects' choices in the Wisconsin experiments run by El-Gamal and Grether. The
                     % inputs are (n,pi) where n is the number of balls in the drawn sample marked N and pi is the pre-announced
                     % prior probability of drawing the sample from cage A. The transformations are (t(n),t(pi)) where
                     % t(n)=log(f(n|A,ndraws)/f(n|B,ndraws)) is the log likelihood ratio where f(n|A,nballs) is the binomial
                     % probability of observing a sample of n balls marked N out of a total of ndraws>=n with replacement from
                     % cage A which has a fraction p(A) of balls marked N and 1-p(A) balls marked G. Similarly for cage B.
                     % t(pi)=log(pi/(1-pi)) is the log prior odds ratio that cage A was selected over cage B.
                     % enter 0 to not transform the inputs when estimating the neural network model. Then the inputs are left
                     % as (n,pi) and not transformed as described above.

% no further changes should ordinarily be made below this line

if (transform_inputs)
 prior_model='llr_lpr';
else
 prior_model='nn';
end

% choose as the "training sample" the experiments with 6 balls in each cage and 6 draws
% with replacement was the sample that subjects were show, which together with the pre-announced
% prior probability of drawing from cage A constitute the information subjects had when choosing
% either cage A or B.

sample{1}='DATA11';
sample{2}='DATA22';   

% choose the evaluation sample for testing the model predictions as the same subjects,
% but where cages have 10 rather 6 balls and 7 rather than 6 balls were drawn from the
% cages with replacement. This is the "evaluation sample"

out_of_sample{1}='DATA12';  
out_of_sample{2}='DATA21';

% load the  data structure that contains the data from the experiment if not already in memory

if (~exist('datastruct'))
load datastruct;  
end

% optimization options

options=optimoptions('fminunc','FunctionTolerance',1e-10,'Display','iter',...
    'Algorithm','trust-region','SpecifyObjectiveGradient',true,'HessianFcn','objective');


  % select experiments from the data structure used to estimate the model: this is the "training sample"

  if (~exist('ydata'))
  [ydata,xdata,pa,pb,draws]=learning_how_to_learn.prepare_data(datastruct,sample);
  end

  % estimate neural network classifier as a reduced-form CCP (reduced form model of the subjects)

  fprintf('Estimating reduced form neural network model of subject choices using Matlab deep learning toolbox\n');
  fprintf('Using a neural network with 2 hidden layers, 2 inputs, 1 hidden unit per layer and 1 output with sigmoid activation\n');
  tic;
  net=patternnet(1); 
  net.layers{1}.transferFcn='logsig';
  net.layers{2}.transferFcn='logsig';
  net.Inputs{1}.processFcns={'fixunknowns'};
  net=train(net,xdata',ydata');
  nn_prediction=net(xdata')';
  nll=perform(net,ydata',nn_prediction');
  layer1_params=[net.b{1}; net.IW{1}'];
  layer2_params=[net.b{2}; net.LW{2}];

  fprintf('Number of observations: %i  Crossentropy (average negative log-likelihood): %g total log-likelihood  %g\n',...
     numel(ydata),nll,-nll*numel(ydata));
  fprintf('Estimated parameters (layer2; layer1)\n');
  [layer2_params; layer1_params]
  
  [my_nn_nll,nn_dllf,nn_hllf,nn_im,my_nn_prediction]=learning_how_to_learn.structural_blogit(ydata,xdata,pa,pb,draws,...
    -[layer2_params; layer1_params],'nn');

  fprintf('Matlab NN log-likelihood: %g  My NN log-likelihood: %g\n',-nll*numel(ydata),-my_nn_nll);
  toc

  if (exist('my_structural_thetahat5_wisconsin'))
    starttheta=my_structural_thetahat5_wisconsin;
  else
    if (exist('my_structural_thetahat5_wisconsin.mat'))
      load my_structural_thetahat5_wisconsin;
      starttheta=my_structural_thetahat5_wisconsin;
    else
      starttheta=rand(5,1);
    end
  end

  tic;
  [my_structural_thetahat5_wisconsin,sllf,exitflag,output,grad,hessian]=...
  fminunc( @(theta) learning_how_to_learn.structural_blogit(ydata,xdata,pa,pb,draws,theta,prior_model),starttheta,options);
  stderr_5p_insample=sqrt(diag(inv(hessian)));
  fprintf('Estimation of 2 layer neural network with 5 parameters with my version\n');
  fprintf('Matlab NN   My NN  My std errors\n');
   [ [layer2_params; layer1_params] my_structural_thetahat5_wisconsin,stderr_5p_insample]
  fprintf('My log-likelihood at optimum: %g\n',-sllf);
  sllf_5p_insample=-sllf;
  fprintf('Matlab log-likelihood at optimum from Matlab deep learning toolbox: %g\n',-nll*numel(ydata)); 
  toc
  save('my_structural_thetahat5_wisconsin','my_structural_thetahat5_wisconsin');

  fprintf('Now estimate 4 parameter structural logit model\n');

  if (exist('my_structural_thetahat4_wisconsin'))
    starttheta=my_structural_thetahat4_wisconsin;
  else
    if (exist('my_structural_thetahat4_wisconsin.mat'))
      load my_structural_thetahat4_wisconsin;
      starttheta=my_structural_thetahat4_wisconsin;
    else
      starttheta=[1; 0; -1; -1];
    end
  end

  tic;
  [my_structural_thetahat4_wisconsin,sllf,exitflag,output,grad,hessian]=...
  fminunc( @(theta) learning_how_to_learn.structural_blogit(ydata,xdata,pa,pb,draws,theta,'structural_blogit'),starttheta,options);
  stderr_4p_insample=sqrt(diag(inv(hessian)));
  sllf_4p_insample=-sllf;
  fprintf('maximum likelihood estimates  standard errors gradient of loglikelihood\n');
  names=cell(4,1);
  names{1}='sigma';
  names{2}='constant';
  names{3}='log likelihood ratio';
  names{4}='log prior ratio';
  stderr=sqrt(diag(inv(hessian)));
  for i=1:4
     fprintf('%20s %10.4f %10.4f %10.4e\n',names{i},my_structural_thetahat4_wisconsin(i),stderr_4p_insample(i),grad(i));
  end
  fprintf('Total negative log-likelihood: %g  average negative log-likelihood: %g\n\n',sllf,sllf/numel(ydata));
  save('my_structural_thetahat4_wisconsin','my_structural_thetahat4_wisconsin');
  toc

  tic;
  fprintf('\nMaximum likelihood estimation of a restricted "noisy Bayesian" model\n');
  truetheta=[0; -1; -1];
  [restricted_sigma,llfr]=...
  fminbnd(@(x) learning_how_to_learn.structural_blogit(ydata,xdata,pa,pb,draws,[x; truetheta],'structural_blogit'),0,1);
  llfr=-llfr;
  fprintf('Maximum likelihood estimate of sigma in restricted "noisy Bayesian model" model %g, log-likehood value: %g\n',...
    restricted_sigma,llfr);
  fprintf('P-value of likeihood ratio test of noisy Bayesian model vs unrestricted structural logit model: %g\n',...
    chi2cdf(2*(-sllf-llfr),3,'upper'));
  restricted_sigma_insample=restricted_sigma;
  llf_nb_insample=llfr;
  toc

  % now load data for the counterfactuals and evaluate the various models in terms of their counterfactual predictions

  if (~exist('cydata'))
  [cydata,cxdata,cpa,cpb,cdraws]=learning_how_to_learn.prepare_data(datastruct,out_of_sample);
  end

  % compare estimated likelihood of 5 parameter reduced-form Neural network to likelihood from the evaluation sample

  starttheta=my_structural_thetahat5_wisconsin;
  [my_cstructural_thetahat5_wisconsin,sllf,exitflag,output,grad,hessian]=...
  fminunc( @(theta) learning_how_to_learn.structural_blogit(cydata,cxdata,cpa,cpb,cdraws,theta,prior_model),starttheta,options);
  fprintf('5 parameter untransformed NN log-likelihood at optimum: %g\n',-sllf);
  save('my_cstructural_thetahat5_wisconsin','my_cstructural_thetahat5_wisconsin');
  fprintf('maximum likelihood estimates of NN (untransformed inputs) on evaluation data standard errors gradient of loglikelihood\n');
  names=cell(5,1);
  names{1}='output bias';
  names{2}='output weight';
  names{3}='input bias';
  names{4}='log likelihood ratio';
  names{5}='log prior ratio';
  stderr_5p_outsample=sqrt(diag(inv(hessian)));
  for i=1:5
     fprintf('%20s %10.4f %10.4f %10.4e\n',names{i},my_cstructural_thetahat5_wisconsin(i),stderr_5p_outsample(i),grad(i));
  end
  fprintf('Total negative log-likelihood: %g  average negative log-likelihood: %g\n\n',sllf,sllf/numel(cydata));
  sllf_5p_outsample=-sllf;

  fprintf('Comparison for in-sample and out-of-sample likelihoods and parameters\n');
  fprintf('                In-sample   Out-of-sample\n');
  for i=1:5
     fprintf('%20s %10.4f %10.4f\n',names{i},my_structural_thetahat5_wisconsin(i),my_cstructural_thetahat5_wisconsin(i));
  end
  fprintf('Observations in "training sample" %i   Observations in "evaluation sample" %i\n',numel(ydata),numel(cydata));
  fprintf('Optimized likelihood per obs (training sample):   %g\n',sllf_5p_insample/numel(ydata));
  fprintf('Optimized likelihood per obs (evaluation sample): %g\n',sllf_5p_outsample/numel(cydata));

  % calculate the predicted probabilities of choosing cage A in the training sample and evaluation sample

  [llf,dllf,hllf,im,cpa_5p_insample]=learning_how_to_learn.structural_blogit(ydata,xdata,pa,pb,draws,...
  my_structural_thetahat5_wisconsin,prior_model);  

  [llf,dllf,hllf,im,cpa_5p_outsample]=learning_how_to_learn.structural_blogit(cydata,cxdata,cpa,cpb,cdraws,...
  my_structural_thetahat5_wisconsin,prior_model);  
  sllf_5p_inoutsample=-llf;
  fprintf('Likelihood per obs (in-sample parameters used in evaluation sample): %g\n\n',sllf_5p_inoutsample/numel(cydata));

  [llf,dllf,hllf,im,cpa_5p_best_outsample]=learning_how_to_learn.structural_blogit(cydata,cxdata,cpa,cpb,cdraws,...
  my_cstructural_thetahat5_wisconsin,prior_model);  

  my_nn5_insample_prediction=(cpa_5p_insample>.5);
  my_nn5_outsample_prediction=(cpa_5p_outsample>.5);
  my_nn5_best_outsample_prediction=(cpa_5p_best_outsample>.5);

  fprintf('Percent of choices correctly predicted in-sample (training sample):  %g\n',100*sum(my_nn5_insample_prediction==ydata)/numel(ydata));
  fprintf('Percent correctly predicted (in-sample params used out-of-sample:    %g\n',...
    100*sum(my_nn5_outsample_prediction==cydata)/numel(cydata));
  fprintf('Percent correctly predicted for MLE parameters in evaluation sample: %g\n\n',...
    100*sum(my_nn5_best_outsample_prediction==cydata)/numel(cydata));

  % compare estimated likelihood of 4 parameter structural logit model to likelihood estimated using  "evaluation sample"

  starttheta=my_structural_thetahat4_wisconsin;
  [my_cstructural_thetahat4_wisconsin,sllf,exitflag,output,grad,hessian]=...
  fminunc( @(theta) learning_how_to_learn.structural_blogit(cydata,cxdata,cpa,cpb,cdraws,theta,'structural_blogit'),starttheta,options);
  fprintf('My log-likelihood at optimum: %g\n',-sllf);
  save('my_cstructural_thetahat4_wisconsin','my_cstructural_thetahat4_wisconsin');
  fprintf('maximum likelihood estimates on evaluation data standard errors gradient of loglikelihood\n');
  names=cell(4,1);
  names{1}='sigma                         ';
  names{2}='subjective posterior intercept';
  names{3}='weight on log likelihood ratio';
  names{4}='weight on log prior ratio     ';
  stderr_4p_outsample=sqrt(diag(inv(hessian)));
  for i=1:4
     fprintf('%20s %10.4f %10.4f %10.4e\n',names{i},my_cstructural_thetahat4_wisconsin(i),stderr_4p_outsample(i),grad(i));
  end
  fprintf('Total negative log-likelihood: %g  average negative log-likelihood: %g\n\n',sllf,sllf/numel(cydata));
  sllf_4p_outsample=-sllf;

  fprintf('Comparison of  in-sample and out-of-sample likelihoods and parameters\n');
  fprintf('                           In-sample   Out-of-sample\n');
  for i=1:4
     fprintf('%20s %10.4f %10.4f\n',names{i},my_structural_thetahat4_wisconsin(i),my_cstructural_thetahat4_wisconsin(i));
  end
  fprintf('Observations in "training sample" %i   Observations in "evaluation sample" %i\n',numel(ydata),numel(cydata));
  fprintf('Optimized likelihood per obs training sample:      %g\n',sllf_4p_insample/numel(ydata));
  fprintf('Optimized likelihood per obs in evaluation sample: %g\n',sllf_4p_outsample/numel(cydata));

  % calculate the predicted probabilities of choosing cage A in the training sample and evaluation sample

  [llf,dllf,hllf,im,cpa_4p_insample]=learning_how_to_learn.structural_blogit(ydata,xdata,pa,pb,draws,...
  my_structural_thetahat4_wisconsin,'structural_blogit');  

  [llf,dllf,hllf,im,cpa_4p_outsample]=learning_how_to_learn.structural_blogit(cydata,cxdata,cpa,cpb,cdraws,...
  my_structural_thetahat4_wisconsin,'structural_blogit');  
  sllf_4p_inoutsample=-llf;
  fprintf('Likelihood per obs (training sample parameters used for evaluation sample): %g\n\n',sllf_4p_inoutsample/numel(cydata));

  [llf,dllf,hllf,im,cpa_4p_best_outsample]=learning_how_to_learn.structural_blogit(cydata,cxdata,cpa,cpb,cdraws,...
  my_cstructural_thetahat4_wisconsin,'structural_blogit');  

  my_nn4_insample_prediction=(cpa_4p_insample>.5);
  my_nn4_outsample_prediction=(cpa_4p_outsample>.5);
  my_nn4_best_outsample_prediction=(cpa_4p_best_outsample>.5);

  fprintf('Percent of choices correctly predicted training sample:                     %g\n',...
    100*sum(my_nn4_insample_prediction==ydata)/numel(ydata));
  fprintf('Percent correctly predicted using training parameters in evaluation sample: %g\n',...
    100*sum(my_nn4_outsample_prediction==cydata)/numel(cydata));
  fprintf('Percent correctly predicted with mle parameters in evaluation sample:       %g\n\n',...
    100*sum(my_nn4_best_outsample_prediction==cydata)/numel(cydata));

  % compare estimated likelihood of 1 parameter "noisy Bayesian" model to likelihood estimated using  "evaluation sample"

  tic;
  fprintf('\nMaximum likelihood estimation of a restricted "noisy Bayesian" model on evaluation data set\n');
  truetheta=[0; -1; -1];
  [restricted_sigma,llfr]=...
  fminbnd(@(x) learning_how_to_learn.structural_blogit(cydata,cxdata,cpa,cpb,cdraws,[x; truetheta],'structural_blogit'),0,1);
  llfr=-llfr;
  fprintf('Maximum likelihood estimate of sigma in restricted "noisy Bayesian model" model %g, log-likehood value: %g\n',...
    restricted_sigma,llfr);
  fprintf('P-value of likeihood ratio test of noisy Bayesian model vs unrestricted structural logit model: %g\n',...
    chi2cdf(2*(sllf_4p_outsample-llfr),3,'upper'));
  restricted_sigma_outsample=restricted_sigma;
  llf_nb_outsample=llfr;
  toc

  fprintf('Comparison of in-sample and out-of-sample estimates of sigma parameter for noisy Bayesian model\n');
  fprintf('Training sample  Evaluation sample\n');
  fprintf('sigma: %g        %g\n',restricted_sigma_insample,restricted_sigma_outsample);
  fprintf('Maximized likelihood per observation, noisy Bayesian model training sample:   %g\n',llf_nb_insample/numel(ydata));
  fprintf('Maximized likelihood per observation, noisy Bayesian model evaluation sample: %g\n',llf_nb_outsample/numel(cydata));

  % calculate the predicted probabilities of choosing cage A in the training sample and evaluation sample

  [llf,dllf,hllf,im,cpa_nb_insample]=learning_how_to_learn.structural_blogit(ydata,xdata,pa,pb,draws,...
  [restricted_sigma_insample; truetheta],'structural_blogit');  

  [llf,dllf,hllf,im,cpa_nb_outsample]=learning_how_to_learn.structural_blogit(cydata,cxdata,cpa,cpb,cdraws,...
  [restricted_sigma_insample; truetheta],'structural_blogit');  
  llf_nb_inoutsample=-llf;

  [llf,dllf,hllf,im,cpa_nb_best_outsample]=learning_how_to_learn.structural_blogit(cydata,cxdata,cpa,cpb,cdraws,...
  [restricted_sigma_outsample; truetheta],'structural_blogit');  
  fprintf('Likelihood per observation of noisy Bayesian model from training sample applied to evaluation sample: %g\n',...
  llf_nb_inoutsample/numel(cydata));

  my_nb_insample_prediction=(cpa_nb_insample>.5);
  my_nb_outsample_prediction=(cpa_nb_outsample>.5);
  my_nb_best_outsample_prediction=(cpa_nb_best_outsample>.5);

  fprintf('Percent of choices correctly predicted training sample:                            %g\n',...
     100*sum(my_nb_insample_prediction==ydata)/numel(ydata));
  fprintf('Percent correctly predicted using training sample parameters in evaluation sample: %g\n',...
     100*sum(my_nb_outsample_prediction==cydata)/numel(cydata));
  fprintf('Percent correctly using MLE parameters in evaluation sample:                       %g\n\n',...
     100*sum(my_nb_best_outsample_prediction==cydata)/numel(cydata));

  % do plots to visually compare the data to the in-sample and out-of-sample model predictions
  
  true_bayes_posterior_ts=learning_how_to_learn.subjective_posterior_prob(xdata,pa,pb,draws,[0;-1;-1],'llr_lpr');
  true_bayes_posterior_es=learning_how_to_learn.subjective_posterior_prob(cxdata,cpa,cpb,cdraws,[0;-1;-1],'llr_lpr');

  true_bayes_posterior_ts=round(true_bayes_posterior_ts,5,'significant');
  true_bayes_posterior_es=round(true_bayes_posterior_es,5,'significant');
 
  up_ts=unique(true_bayes_posterior_ts);
  up_es=unique(true_bayes_posterior_es);

  nup_ts=numel(up_ts);
  nup_es=numel(up_es);

  cpa_ts=zeros(nup_ts,1);
  cpa_es=zeros(nup_es,1);
  nobs_ts=zeros(nup_ts,1);
  nobs_es=zeros(nup_es,1);

  nn5_ts=zeros(nup_ts,1);
  sl4_ts=zeros(nup_ts,1);

  nn5_outsample_es=zeros(nup_es,1);
  sl4_outsample_es=zeros(nup_es,1);
  sl4_mle_es=zeros(nup_es,1);
  nn5_mle_es=zeros(nup_es,1);

  for i=1:nup_ts
     ind=find(true_bayes_posterior_ts==up_ts(i));
     cpa_ts(i)=mean(ydata(ind));
     nobs_ts(i)=numel(ind);
     nn5_ts(i)=mean(cpa_5p_insample(ind));
     sl4_ts(i)=mean(cpa_4p_insample(ind));
  end

  for i=1:nup_es
     ind=find(true_bayes_posterior_es==up_es(i));
     cpa_es(i)=mean(cydata(ind));
     nobs_es(i)=numel(ind);
     nn5_outsample_es(i)=mean(cpa_5p_outsample(ind));
     sl4_outsample_es(i)=mean(cpa_4p_outsample(ind));
     sl4_mle_es(i)=mean(cpa_4p_best_outsample(ind));
     nn5_mle_es(i)=mean(cpa_5p_best_outsample(ind));
  end

  f1=figure(1);
  clf(f1);
  hold on;
  plot(up_ts,cpa_ts,'b-','Linewidth',2);
  plot(up_es,cpa_es,'r-','Linewidth',2);
  line([0 .5],[0 0],'LineStyle',':','Linewidth',2);
  line([.5 .5],[0 1],'LineStyle',':','Linewidth',2);
  line([.5 1],[1 1],'LineStyle',':','Linewidth',2);
  axis('square');
  legend('6 IID draws from cages with 6 balls','7 IID draws from cages with 10 balls',...
   'Location','Northwest');
  xlabel('True posterior');
  ylabel('Predicted fractions of subjects of choosing cage A');
  title({'Subject choices in Wisconsin experiments','Training sample: blue, Evaluation sample: red'});
  hold off;

  f2=figure(2);
  clf(f2);
  hold on;
  plot(up_ts,cpa_ts,'k-','Linewidth',2);
  plot(up_ts,nn5_ts,'r-','Linewidth',2);
  plot(up_ts,sl4_ts,'b-','Linewidth',2);
  line([0 .5],[0 0],'LineStyle',':','Linewidth',2);
  line([.5 .5],[0 1],'LineStyle',':','Linewidth',2);
  line([.5 1],[1 1],'LineStyle',':','Linewidth',2);
  axis('square');
  legend('Data','Neural network','Structural logit','Location','Northwest');
  xlabel('True posterior');
  ylabel('Actual and predicted fractions of subjects of choosing cage A');
  title('Comparison of model fit: training sample');
  hold off;

  f3=figure(3);
  clf(f3);
  hold on;
  plot(up_es,cpa_es,'k-','Linewidth',2);
  plot(up_es,nn5_outsample_es,'r-','Linewidth',2);
  plot(up_es,sl4_outsample_es,'b-','Linewidth',2);
  line([0 .5],[0 0],'LineStyle',':','Linewidth',2);
  line([.5 .5],[0 1],'LineStyle',':','Linewidth',2);
  line([.5 1],[1 1],'LineStyle',':','Linewidth',2);
  axis('square');
  legend('Data','Neural network','Structural logit','Location','Northwest');
  xlabel('True posterior');
  ylabel('Actual and predicted fractions of subjects of choosing cage A');
  title('Comparison of counterfactual predictions: evaluation sample');
  hold off;

  f4=figure(4);
  clf(f4);
  hold on;
  plot(up_es,cpa_es,'k-','Linewidth',2);
  plot(up_es,nn5_outsample_es,'r-','Linewidth',2);
  plot(up_es,nn5_mle_es,'b-','Linewidth',2);
  line([0 .5],[0 0],'LineStyle',':','Linewidth',2);
  line([.5 .5],[0 1],'LineStyle',':','Linewidth',2);
  line([.5 1],[1 1],'LineStyle',':','Linewidth',2);
  axis('square');
  legend('Data','NN prediction','NN fitted','Location','Northwest');
  xlabel('True posterior');
  ylabel('Actual and predicted fractions of subjects of choosing cage A');
  title('NN predicted vs fitted choices: evaluation sample');
  hold off;

  f5=figure(5);
  clf(f5);
  hold on;
  plot(up_ts,cpa_ts,'k-','Linewidth',2);
  plot(up_ts,sl4_ts,'r-','Linewidth',2);
  line([0 .5],[0 0],'LineStyle',':','Linewidth',2);
  line([.5 .5],[0 1],'LineStyle',':','Linewidth',2);
  line([.5 1],[1 1],'LineStyle',':','Linewidth',2);
  axis('square');
  legend('Data','Sructural logit','Location','Northwest');
  xlabel('True posterior');
  ylabel('Actual and predicted fractions of subjects of choosing cage A');
  title('Structural logit fit: training sample');
  hold off;

  f6=figure(6);
  clf(f6);
  hold on;
  plot(up_es,cpa_es,'k-','Linewidth',2);
  plot(up_es,sl4_outsample_es,'r-','Linewidth',2);
  plot(up_es,sl4_mle_es,'b-','Linewidth',2);
  line([0 .5],[0 0],'LineStyle',':','Linewidth',2);
  line([.5 .5],[0 1],'LineStyle',':','Linewidth',2);
  line([.5 1],[1 1],'LineStyle',':','Linewidth',2);
  axis('square');
  legend('Data','Structural logit prediction','Structural logit MLE','Location','Northwest');
  xlabel('True posterior');
  ylabel('Actual and predicted fractions of subjects of choosing cage A');
  title('Structural logit prediction: evaluation sample');
  hold off;
