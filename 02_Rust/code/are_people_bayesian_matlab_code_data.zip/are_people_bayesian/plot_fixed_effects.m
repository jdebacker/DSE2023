% plot_fixed_effects.m  program to plot and do k-means clustering on individual-specific parameter estimates
%                       of the subject-specific parameters estimated by maximum likelihood and logistic regression
%                       John Rust, Georgetown University, February 2021



nsubjects=size(thetahat,2); % number of subjects in the California experiments of El-Gamal and Grether
model='llr_lpr';

if (strcmp(model,'llr_lpr'))
  truetheta=[0; -1; -1];
else
  truetheta=[6*(log(1/2)-log(1/3)); -log(2); 1];
end

nballs=6;
prior=(0:.01:1)';
sp=size(prior,1);

xcoord_all=[];
ycoord_all=[];
zcoord_all=[];
xcoord_converged=[];
ycoord_converged=[];
zcoord_converged=[];

meantheta_all=zeros(3,1);
meantheta_converged=zeros(3,1);
all_converged=0;

subjective_posterior={};
subject_scutoffs={};

params_all=[];
params_converged=[];

for subject=1:nsubjects

  params_all=[params_all; thetahat{subject}'];

  if (exitflag{subject} > 0)
      params_converged=[params_converged; thetahat{subject}'];
  end

  meantheta_all=meantheta_all+thetahat{subject};

  xcoord_all=[xcoord_all; thetahat{subject}(2)];
  ycoord_all=[ycoord_all; thetahat{subject}(3)];
  zcoord_all=[zcoord_all; thetahat{subject}(1)];

  if (exitflag{subject})
     all_converged=all_converged+1;
     meantheta_converged=meantheta_converged+thetahat{subject};
     xcoord_converged=[xcoord_converged; thetahat{subject}(2)];
     ycoord_converged=[ycoord_converged; thetahat{subject}(3)];
     zcoord_converged=[zcoord_converged; thetahat{subject}(1)];
  end;

  subjective_posterior_a=zeros(size(prior,1),nballs+1);

  for i=0:nballs;
    subjective_posterior_a(:,i+1)=learning_how_to_learn.subjective_posterior_prob([i*ones(sp,1) prior],thetahat{subject},model);
  end;

  subjective_posterior{subject}=subjective_posterior_a;

  % calculate the "subjective cutoffs" (scutoffs) where the subjective_posterior_a first equals 1/2, by interpolation
  scutoffs=zeros(nballs,1);
  for i=0:nballs
   ind=min(find(subjective_posterior_a(:,nballs+1-i)>=1/2));
   if (ind > 1)
   scutoffs(i+1)=prior(ind-1)+((1/2-subjective_posterior_a(ind,nballs+1-i))/(subjective_posterior_a(ind,nballs+1-i)-subjective_posterior_a(ind-1,nballs+1-i)))*(prior(ind)-prior(ind-1));
   end
  end

  subject_scutoffs{subject}=scutoffs;

end;

fprintf('Mean theta for all %i subjects Mean theta for all %i converged estimations and Bayes Rule theta (and ratios relative to this theta)\n',nsubjects,all_converged);
meantheta_all=meantheta_all/nsubjects;
meantheta_converged=meantheta_converged/all_converged;
[meantheta_all meantheta_converged truetheta meantheta_all./truetheta meantheta_converged./truetheta]

myfigure;
clf;
scatter3(xcoord_all,ycoord_all,zcoord_all,'filled');	
title(sprintf('Subject specific \\theta estimates, all %i subjects',nsubjects));
xlabel(sprintf('\\theta_1'));
ylabel(sprintf('\\theta_2'));
zlabel(sprintf('\\theta_0'));

myfigure;
clf;
scatter3(xcoord_converged,ycoord_converged,zcoord_converged,'filled');	
title(sprintf('Subject specific \\theta estimates, all %i converged runs',all_converged));
xlabel(sprintf('\\theta_1'));
ylabel(sprintf('\\theta_2'));
zlabel(sprintf('\\theta_0'));


%  Now use k-means clustering to identify different types in the subject pool, and plot them

[idx_all,C_all]=kmeans(params_all,3);  % do k-means clustering of all parameters, discard any cluster with small numbers of elements

fe_thetahat=[];
fe_tw=[];        % vector with the fractions of subjects of each type

params_all_outliers_excluded=[];
outliers=0;
included_cluster_indices=[];

for i=1:3
   if (sum(idx_all == i) < 5)
     outliers=sum(idx_all==i);
     fprintf('discarding cluster %i: it has only %i elements (most likely outliers)\n',i,sum(idx_all==i));
     fprintf('Centroid (mean value) of points in this discarded cluster\n');
     C_all(i,:)
   else
      included_cluster_indices=[included_cluster_indices; i];
      fe_thetahat=[fe_thetahat; C_all(i,:)'];
      fe_tw=[fe_tw; sum(idx_all==i)];
      params_all_outliers_excluded=[params_all_outliers_excluded; params_all(find(idx_all==i),:)];
   end
end

fe_tw=fe_tw/sum(fe_tw);
save('fe_thetahat','fe_thetahat');
save('fe_tw','fe_tw');
xcoord_all=params_all(:,2);
ycoord_all=params_all(:,3);
zcoord_all=params_all(:,1);

ind1_all=find(idx_all==included_cluster_indices(1));
ind2_all=find(idx_all==included_cluster_indices(2));

myfigure;
clf;
hold on;
scatter3(xcoord_all(ind1_all),ycoord_all(ind1_all),zcoord_all(ind1_all),'bo','filled');	
scatter3(xcoord_all(ind2_all),ycoord_all(ind2_all),zcoord_all(ind2_all),'ro','filled');	
c1=C_all(included_cluster_indices(1),:);
c2=C_all(included_cluster_indices(2),:);
scatter3(c1(2),c1(3),c1(1),120,'d','k','filled');
scatter3(c2(2),c2(3),c2(1),120,'d','k','filled');
title(sprintf('Subject specific \\theta estimates, all %i subjects, %i outliers excluded',nsubjects,outliers));
xlabel(sprintf('\\theta_1'));
ylabel(sprintf('\\theta_2'));
zlabel(sprintf('\\theta_0'));
view(50,40);
hold off;

%  Now use k-means clustering to identify different types in the subject pool, and plot them (for converged parameters only)

%params_converged=params_all;

[idx,C]=kmeans(params_converged,3);  % do k-means clustering of all parameters, discard any cluster with small numbers of elements

%fe_thetahat=[];
%fe_tw=[];        % vector with the fractions of subjects of each type

params_converged_outliers_excluded=[];
outliers=0;
included_cluster_indices=[];

for i=1:3
   if (sum(idx == i) < 5)
     outliers=sum(idx==i);
     fprintf('discarding cluster %i: it has only %i elements (most likely outliers)\n',i,sum(idx==i));
     fprintf('Centroid (mean value) of points in this discarded cluster\n');
     C(i,:)
   else
      included_cluster_indices=[included_cluster_indices; i];
%      fe_thetahat=[fe_thetahat; C(i,:)'];
%      fe_tw=[fe_tw; sum(idx==i)];
      params_converged_outliers_excluded=[params_converged_outliers_excluded; params_converged(find(idx==i),:)];
   end
end

%fe_tw=fe_tw/sum(fe_tw);
%save('fe_thetahat','fe_thetahat');
%save('fe_tw','fe_tw');
xcoord_all=params_converged(:,2);
ycoord_all=params_converged(:,3);
zcoord_all=params_converged(:,1);

ind1=find(idx==included_cluster_indices(1));
ind2=find(idx==included_cluster_indices(2));
%ind3=find(idx==included_cluster_indices(3));

myfigure;
clf;
hold on;
scatter3(xcoord_all(ind1),ycoord_all(ind1),zcoord_all(ind1),'ro','filled');	
scatter3(xcoord_all(ind2),ycoord_all(ind2),zcoord_all(ind2),'bo','filled');	
%scatter3(xcoord_all(ind3),ycoord_all(ind3),zcoord_all(ind3),'go','filled');	
c1=C(included_cluster_indices(1),:);
c2=C(included_cluster_indices(2),:);
%c3=C(included_cluster_indices(3),:);
scatter3(c1(2),c1(3),c1(1),120,'d','k','filled');
scatter3(c2(2),c2(3),c2(1),120,'d','k','filled');
%scatter3(c3(2),c3(3),c3(1),120,'d','k','filled');
title(sprintf('Subject specific \\theta estimates, %i subjects, %i outliers excluded',size(params_converged,1),outliers));
xlabel(sprintf('\\theta_1'));
ylabel(sprintf('\\theta_2'));
zlabel(sprintf('\\theta_0'));
view(50,40);
hold off;

