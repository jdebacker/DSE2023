The data for the December 1995 JASA article "Are People Bayesian" are contained in six files. 
The files are named for the school viz. csula,oxy,pcc and ucla and the treatment 'no' and 'pay'. 
The subjects in the 'no' files were paid a flat fee for participating and those in the 'pay' files received a 
bonus if a randomly chosen response was correct. Thus the file usclno.pay should have data for subjects from ucla who were paid a flat fee.

Each file is organized as follows. 

The first line is a list of numbers 2, 3 and 4 giving the ordered list of the number of chances out of 6 for drawing cage A ( the cage with 4 Ns and 2Gs). 
The second line consists of integers from 0 to 6 giving for each round of the experiment the number of Ns drawn out of 6 draws.
The remaining lines contain a subject number and a list of 0s and 1s which give the subjects' responses with 1 meaning they subject picked A and 0 coded for B.

