% learning_how_to_learn.m:  this program can be viewed as a machine learning
%                           algorithm that learns via "supervised learning" about how to classify
%                           samples drawn from one of two possible cages correctly by showing the
%                           samples that are drawn for different prior probabilities of drawing the
%                           cage A with 4 N balls and  2 G balls vs cage B with 3 N balls and 3 G balls
%                           with replacement as describe in the 1995 JASA paper by El-Gamal and Grether,
%                           "Are People Bayesian? Uncovering Behavioral Strategies", and additional 
%                           experiments done with cages with 10 balls and different priors as reported in the
%                           1999 paper by El-Gamal and Grether "Changing Decision Rules: Uncovering Behavioral
%                           Strategies using Estimation-Classification (EC)".
%
%                           John Rust, Georgetown University, August 2023  

classdef learning_how_to_learn 

properties (Constant)
    debg = 'on'; % 'on', 'off', or 'detailed'   
  end%properties
methods (Static)

 function [ydata,xdata,pa,pb,draws]=prepare_data(datastruct,group);

 % group is currently 
 % 'all_pooled' for all subjects 
 % 'all_pooled_california' for all subjects in the california experiments
 % 'all_pooled_wisconsin' for all subjects in the wisconsin experiments
 % 'all_pay' for all subjects in experiments where subjects were paid for correct answer
 % 'all_nopay' for all subjects in experiments where subjects were paid for correct answer
 % 'all_pay_california' for all subjects in experiments where subjects were paid for correct answer (california experiments)
 % 'all_nopay_california' for all subjects in experiments where subjects were paid for correct answer (california experiments)
 % 'all_pay_wisconsin' for all subjects in experiments where subjects were paid for correct answer (wisconsin experiments)
 % 'all_nopay_wisconsin' for all subjects in experiments where subjects were paid for correct answer (wisconsin experiments)
 % 'all_indvidual' return [ydata,xdata] as cell arrays, where each array contains the [ydata,xdata] matrix for an individual subject 
 % 'all_indvidual_wisconsin' return [ydata,xdata] as cell arrays, where each array contains the 
 %                           [ydata,xdata] matrix for an individual subject  from wisconsin experiments
 % 'all_indvidual_california' return [ydata,xdata] as cell arrays, where each array contains the 
 %                            [ydata,xdata] matrix for an individual subject from california experiments
 %
 %  in addition, individual experiments (elements of the datastruct) can be chosen by name, e.g. 
 %  'UCLA.pay' 'UCLANO.pay' 'PCCNO.pay' 'OXY.pay' 'OXYNO.pay' 'CSULA.pay' 'CSULANO.pay'
 %  and for the Wisconsin experiments, 'DATA11' 'DATA12'  'DATA21' and 'DATA22' 
 %  or if group is a cell array of any of the above, all subjects in strings in the cell array are included in the outputs
 %  except you are not allowed to mixed individual data (where the string includes `individual' and non-individual (i.e. grouped)
 %  data, where the panel structure data does not matter.

 % Outputs

 % ydata  a nobs x 1 vector (there nobs is total number of subjects and trials in all included experiments) 
 %        indicator of the chosen cage: ydata=1 (cage A) ydata=0 (cage B)
 % xdata  an nobs x 2 matrix (first column is the number of balls marked N that were drawn and shown to subject, 
 %        and second column is the prior probability of drawing from cage A)
 % pa     a nobs x 1 vector with the fraction of balls marked N in cage A
 % pb     a nobs x 1 vector with the fraction of balls marked N in cage B
 % draws  a nobs x 1 vector with the total number of balls drawn (with replacement) from either cage
 % balls  a nobs x 1 vector with the total number of balls in each cage
 %
 % When group is 'all_individual' 'all_inidividual_wisconsin' or 'all_individual_california' the returns are 
 % cell arrays with length equal to number of experiments times number of subjects, so each are grouped by each
 % individual subject to enable subject-specific model estimations, such as fixed-effects, the EC, and Heckman-Singer methods.

 ngroups=size(datastruct,2);  

 individual_data=0;

 if iscell(group)
    ngroup=numel(group);
    groups=group;
    for i=1:ngroup
      if contains(group{i},'individual')
         individual_data=1;
      end
    end
 else
    ngroup=1;
    groups{1}=group;
    if contains(group,'individual')
         individual_data=1;
    end
 end
    
 if (individual_data)
    ydata={};   % with individual level (panel data) estimation the returns of this function are cell arrays, 
    xdata={};   % with each array element containing the data for an individual subject.
    pa={};      % Hence this way of returning the data enables looping and estimating individual-specific models of subject choices
    pb={};
    draws={};
 else 
   ydata=[];
   xdata=[];
   pa=[];
   pb=[];
   draws=[];
 end

 for gi=1:ngroup   % outer loop over all elements of the group cell array input (ngroup=1 if group is just a string)  

  group=groups{gi};

  if (strcmp(group,'all_pooled'))

    for g=1:ngroups
     
       priors=datastruct(g).priors';
       ndraws=datastruct(g).ndraws';
       subjectchoices=datastruct(g).subjectchoices;
       nsubjects=size(subjectchoices,1);
       ydata=[ydata; subjectchoices(:)];
       ndraws=repmat(ndraws,nsubjects,1);
       priors=repmat(priors,nsubjects,1);
       xdata=[xdata; [ndraws(:) priors(:)/datastruct(g).nballs_prior_cage]];

       nobs=numel(subjectchoices);
       pa=[pa; repmat(datastruct(g).cage_A_balls_marked_N/datastruct(g).nballs,nobs,1)];
       pb=[pb; repmat(datastruct(g).cage_B_balls_marked_N/datastruct(g).nballs,nobs,1)];
       draws=[draws; repmat(datastruct(g).ndraws_from_cage,nobs,1)];

    end

  elseif (~ischar(group)|strcmp(group,'all_pooled_california')|...
           strcmp(group,'all_pooled_wisconsin')|strcmp(group,'all_pay')|...
           strcmp(group,'all_nopay')|strcmp(group,'UCLA.pay')|...
           strcmp(group,'PCCNO.pay')|strcmp(group,'UCLANO.pay')|...
           strcmp(group,'CSULA.pay')|strcmp(group,'CSULANO.pay')|...
           strcmp(group,'OXY.pay')|strcmp(group,'OXYNO.pay')|...
           strcmp(group,'DATA11')|strcmp(group,'DATA12')|...
           strcmp(group,'DATA21') | strcmp(group,'DATA22'))

    for g=1:ngroups

      ok=0;

      if (~ischar(group))
         ind=find(group==g);
         if (ind)
           ok=1;
         end   
      end

      if (strcmp(group,'all_pooled_california') & strcmp(datastruct(g).state,'california'))
        ok=1;
      end
      if (strcmp(group,'all_pooled_wisconsin') & strcmp(datastruct(g).state,'wisconsin'))
        ok=1;
      end
      if (strcmp(group,'all_pay'))
        if (datastruct(g).pay==1)
          ok=1;
        end;
      end
      if (strcmp(group,'all_nopay'))
        if (datastruct(g).pay==0)
          ok=1;
        end;
      end
      if (strcmp(datastruct(g).name,'UCLA.pay') & strcmp(group,'UCLA.pay'))
       ok=1;
      end
      if (strcmp(datastruct(g).name,'UCLANO.pay') & strcmp(group,'UCLANO.pay'))
       ok=1;
      end
      if (strcmp(datastruct(g).name,'PCCNO.pay') & strcmp(group,'PCCNO.pay'))
       ok=1;
      end
      if (strcmp(datastruct(g).name,'OXYNO.pay') & strcmp(group,'OXYNO.pay'))
       ok=1;
      end
      if (strcmp(datastruct(g).name,'OXY.pay') & strcmp(group,'OXY.pay'))
       ok=1;
      end
      if (strcmp(datastruct(g).name,'CSULA.pay') & strcmp(group,'CSULA.pay'))
       ok=1;
      end
      if (strcmp(datastruct(g).name,'CSULANO.pay') & strcmp(group,'CSULANO.pay'))
       ok=1;
      end
      if (strcmp(datastruct(g).name,'DATA11') & strcmp(group,'DATA11'))
       ok=1;
      end
      if (strcmp(datastruct(g).name,'DATA12') & strcmp(group,'DATA12'))
       ok=1;
      end
      if (strcmp(datastruct(g).name,'DATA21') & strcmp(group,'DATA21'))
       ok=1;
      end
      if (strcmp(datastruct(g).name,'DATA22') & strcmp(group,'DATA22'))
       ok=1;
      end
    
      if (ok) 
       fprintf('including %s (datastruct element %i) in the pooled data sample\n',datastruct(g).name,g);
       priors=datastruct(g).priors';
       nballs=datastruct(g).nballs_prior_cage;
       priors=priors/nballs;
       ndraws=datastruct(g).ndraws';
       subjectchoices=datastruct(g).subjectchoices;
       nsubjects=size(subjectchoices,1);
       ydata=[ydata; subjectchoices(:)];
       ndraws=repmat(ndraws,nsubjects,1);
       priors=repmat(priors,nsubjects,1);
       xdata=[xdata; [ndraws(:) priors(:)]];

       nobs=numel(subjectchoices);
       pa=[pa; repmat(datastruct(g).cage_A_balls_marked_N/datastruct(g).nballs,nobs,1)];
       pb=[pb; repmat(datastruct(g).cage_B_balls_marked_N/datastruct(g).nballs,nobs,1)];
       draws=[draws; repmat(datastruct(g).ndraws_from_cage,nobs,1)];

      end

    end

  elseif (strcmp(group,'all_individual')|...
          strcmp(group,'all_individual_wisconsin')|...
          strcmp(group,'all_individual_california'))

   % in this case ydata and xdata are cell arrays of size 1 x nsubjects  and each contains the responses of a single subject

    cc=0;       % index for the cell arrays, one index per subject in the experiment

    for g=1:ngroups

     ok=0;

     if (strcmp(group,'all_individual'))
          ok=1;
     end
     if (strcmp(group,'all_individual_wisconsin') & strcmp(datastruct(g).state,'wisconsin'))
          ok=1;
     end
     if (strcmp(group,'all_individual_california') & strcmp(datastruct(g).state,'california'))
          ok=1;
     end

     if (ok)
     
       fprintf('including %s (datastruct element %i) in the data sample grouped by individual subjects\n',datastruct(g).name,g);
       priors=datastruct(g).priors/datastruct(g).nballs_prior_cage;
       ndraws=datastruct(g).ndraws;
       subjectchoices=datastruct(g).subjectchoices;
       nsubjects=size(subjectchoices,1);
  
       for i=1:nsubjects
          cc=cc+1;
          ydata{cc}=subjectchoices(i,:)';
          xdata{cc}=[ndraws priors];
          nobs=size(ydata{cc},1);
          pa{cc}=repmat(datastruct(g).cage_A_balls_marked_N/datastruct(g).nballs,nobs,1);
          pb{cc}=repmat(datastruct(g).cage_B_balls_marked_N/datastruct(g).nballs,nobs,1);
          draws{cc}=repmat(datastruct(g).ndraws_from_cage,nobs,1);

       end

     end

    end % end of for loop over groups

  else

     fprintf('ERROR in prepare_data: unrecognized group %s entered. Null return.\n',group);
     fprintf('Please check the group argument to prepare_data and re-run\n');
     ydata=nan;
     xdata=nan;

  end % end of if-branch switch to prepare the data in the form and for the subsample requested

 end % end of loop over the different groups in the group cell array argument to this function

 end % end of prepare_data function

 function [spa,dpa,hpa]=subjective_posterior_prob(xdata,pa,pb,draws,theta,model) 

 % computes the estimated logit probability ("subjective posterior of bingo cage A") given "trained parameters" theta
 % If theta values are given by the "true values" this subjective probability coicides with the true posterior from Bayes Rule
 %
 % Outputs:
 %
 % spa   subjective posterior probability of choosing cage A
 % dpa   gradient of spa with respect to the theta parameters
 % hpa   hessian of spa with respect to the theta parameters
 %
 % Inputs: 
 %
 % xdata a k x 2 matrix, where k is the number of different values of x (n,prior) that the subjective prior is evaluated at
 %       The first column of xdata contains n, the number of balls drawn marked N, and the 2nd column is the prior probability of drawing from cage A
 % pa    a kx1 vector of fractions of N balls in bingo cage A 
 % pb    a kx1 vector of fractions of N balls in bingo cage B 
 % draws a kx1 vector of the number of draws (with replacement) from the chosen cage in the experiment
 % 
 % when k=1 (only evaluating at a single (n,prior) observation) then spa is a scalar, dpa is a 3x1 vector and hpa is a 3x3 matrix
 %          since there are actually 3 parameters in theta, where we allow for a constant terms (theta(1)) plus coefficients for
 %          the columns of xdata (theta(2) and theta(3)).
 % when k>1 then spa is a kx1 vector, dpa is a 3xk matrix, and hpa is a 3x3xk three dimensional array

 nobs=size(xdata,1);

 prior=xdata(:,2);

 if (strcmp(model,'llr_lpr') | strcmp(model,'structural_logit') | strcmp(model,'structural_blogit'))   

    % recode the first column of xdata as the log-likeihood ratio log(f(n|A)/f(n|B)) not n
    xdata(:,1)=log(binopdf(xdata(:,1),draws,pa))-log(binopdf(xdata(:,1),draws,pb));

    % recode the second column of xdata as the log prior odds ratio
    xdata(:,2)=log(prior)-log(1-prior);

 end

 if (strcmp(model,'prior_as_log_odds'))
 xdata(:,2)=log(1-prior)-log(prior);  % prior log odds in last column of x matrix
 end
 
 xdata=[ones(nobs,1) xdata];  % add a constant term

 xtheta=xdata*theta;
 spa=1./(1+exp(xtheta));  % compute binary logit probability of selecting the first alternative, i.e. bingo cage A in this example

 if (nargout > 1)
    dpa=-((spa.*(1-spa))').*xdata';
 end

 if (nargout > 2)
   if (nobs==1)
    hpa=-dpa*(1-2*spa)*xdata;
   else
     hpa=zeros(3,3,nobs);
     for i=1:nobs
       hpa(:,:,i)=-dpa(:,i)*(1-2*spa(i))*xdata(i,:);
     end
   end
 end

 end

 function [llf,dllf,hllf,im,cpa]=structural_blogit(ydata,xdata,pa,pb,draws,theta,model)

 % This function can be regarded as computing the log-likelihood function for a "structural" binary logit model of subject choices.
 % This is a log-likelihood function for a structural binary logit model of subject choices with 4 parameters: the 3 parameters
 % entering the subjective_posterior_prob function plus a noise scale parameter sigma indexing the random "errors" in making a decision.
 % However if the size of theta is 5x1, then the interpretation of this model is that of a "neural network of depth 2 and width 1"
 % where (theta(1),theta(2)) are the "output layer" bias term and weight on the 1st layer output (the subjective probability of A)
 % and (theta(3),theta(4),theta(5)) are the input layer parameters with theta(3) the bias term, and theta(4) and theta(5) weights
 % on the two "inputs". Whether the two inputs are simply n and pi, the number of balls drawn marked N and the prior probability
 % that the balls were drawn from cage A, respectively, or transformed versions of these inputs, T(n) and T(pi), where T(n) is the
 % log of the likelihood ratio of cage A over cage B and T(pi) is the log prior odds ratio, log(pi/(1-pi)), depends on the 
 % last argument, model. If model is 'llr_lpr' or 'structural_logit' 'structural_blogit' the above transformations are performed
 % and the interpretation of the model is that of a "structural logit" model that nests Bayes Rule as a special case (the first
 % layer output being the true Bayes Posterior when theta(3)=0, theta(4)=-1, theta(5)=-1). If model is 'prior_as_log_odds' then
 % only the 2nd input pi is transformed, to log(1-pi)-log(pi) and the n input is not transformed. Otherwise if model is none of the
 % above, as long as it is not the empty string, then there are no transformations of the inputs and then this function can be
 % interpreted as a usual neural network of depth 2 and width 1 with either 4 or 5 parameters in total. model='untransformed'
 % or model='nn' is what we suggest to use as the model argument for this case. 
 %
 % We assume that the subject choice is based on a "noisy subjective probability" of choosing cage A and so the subject chooses cage A
 % when the total utility of choosing it is higher, calculated as the sum of the subjective probability that cage A is the chosen cage
 % plus an extreme value shock indexed by the parameter sigma.  This model nests the perfect Bayes Rule decision rule when sigma=0
 % and the parmeters of the subjective choice model are (beta0,beta1,beta2)=(0,-1,-1). theta=(sigma,beta0,beta1,beta2).
 % This function computes the log-likelihood (llf), gradients of the log-likeihood (dllf) and hessian of the log-likelihood (hllf)
 % for the 4 parameters of the binary logit model given binary 0/1 dependent variable ydata (1 if the subject's chosen cage is cage A) 
 % and x variables in xdata are the number of balls marked N that were drawn (first column) and the prior prob of drawing A (second column).

 % outputs:
 % llf is the log-likelihood function
 % dllf is the gradient of log-likelihood function with respect to the 4 or 5 model parameters theta
 % hllf is the 4x4 hessian matrix of the log-likelihood with respect to the 4 or 5 model parameters theta
 % im is the 4x4 information matrix of the log-likelihood: the outer-product of the gradients with respect to 
 % the 4 or 6 model parameters theta
 % cpa is the kx1 vector of predicted probabilities of the "choice probability of A", i.e. the probability the
 % model chooses urn A for each point in the data set

 % inputs:
 % ydata is a vector of 0s and 1s that has nobs rows in it, where y=1 if subject chose cage A and y=0 if subject chose cage B
 % xdata is a matrix with nobs rows and 2 columns, where the first column contains n the 
 %       number of balls drawn marked N and 2nd column is the prior prob of drawing cage A
 % pa    is a vector with nobs rows and 1 column, equaling the fraction of N balls in cage A
 % pb    is a vector with nobs rows and 1 column, equaling the fraction of N balls in cage B
 % draws is a vector with nobs rows and 1 column, equaling the number of balls drawn (with replacement) from the chosen cage

 nobs=size(xdata,1);

 ntheta=numel(theta);      % code switches based on dimension of theta: it must be of size 4 or 5
                           % If theta has 5 elements the first parameter is the "bias" and the other the "weight" on the subjective 
                           % posterior probability of cage A, giving the structural model an alternative interpretation as a
                           % two level neural network with 2 inputs and two hidden layers, the first layer including a bias
                           % term, theta(3) plus weights theta(4) and theta(5), respectively, on the two inputs, log prior odds and
                           % log likelihood ratio, respectively, and the 2nd hidden layer uses the sigmoid output of the first layer
                           % with theta(1) as the bias term and theta(2) the weight on the single output of the first layer. 
 if (strcmp(model,''))
   model='llr_lpr';
 end

 if (ntheta == 4)

    sig=theta(1);
    [spa,dspa,hspa]=learning_how_to_learn.subjective_posterior_prob(xdata,pa,pb,draws,theta(2:4),model);
   
    % cpa=1./(1+exp((1-2*spa)/sigma));  % compute binary logit probability of selecting the first alternative, i.e. bingo cage A in this example
    %
    % Note: to improve numerical stability and accuracy, we do not actually evaluate pa via the formula above. Instead we split observations
    %       into those where the subjective probability is above 1/2 and those where it is below 1/2 and evaluate them separately to avoid
    %       loss of accuracy or program bombing due to possible overflow from evaluating (1-2*pa)/sigma if it takes on large positive values 
    %       Thus, we do not use the obvious way to write the log likelihood below
    %       llf=-sum(ydata.*logpa+(1-ydata).*log1mpa);
    %       and instead evaluate in a mathematically equivalent but numerically stable way below
   
    if (sig == 0)
       cpa=1*(spa>=1/2); 
       if (sum(cpa == ydata)==nobs)
         llf=0;
       else
         llf=-log(0);
       end
    else 
       cpa=zeros(nobs,1);
       logsum=zeros(nobs,1);
       nspa=(1-2*spa)/sig;
       ind=find(spa>1/2);
       indc=find(spa<=1/2);
       if (numel(ind))
         cpa(ind)=1./(1+exp(nspa(ind)));
         logsum(ind)=log(1+exp(nspa(ind)));
       end
       if (numel(indc))
         cpa(indc)=exp(-nspa(indc))./(1+exp(-nspa(indc)));
         logsum(indc)=nspa(indc)+log(1+exp(-nspa(indc)));
       end
       llf=sum(logsum)-sum((1-ydata).*nspa);
    end
                                     
    if (nargout > 1)
      dllf=zeros(4,1);
      gradmat=zeros(nobs,4);
      gradmat(:,1)=(cpa-ydata).*nspa;
      gradmat(:,2:4)=2*(cpa-ydata).*dspa';
      dllf=sum(gradmat)'/sig;
    end
   
    if (nargout > 2)
      hllf=zeros(4,4);
      hllf(1)=-2*dllf(1)/sig+sum(cpa.*(1-cpa).*nspa.*nspa)/(sig^2);
      fouroversig=4/sig;
      for i=1:nobs
        hllf(2:4,2:4)=hllf(2:4,2:4)+2*(cpa(i)-ydata(i))*hspa(:,:,i)+fouroversig*cpa(i)*(1-cpa(i))*dspa(:,i)*(dspa(:,i)');
      end
      hllf(1,2:4)=2*(sum(cpa.*(1-cpa).*nspa.*dspa')-sum((cpa-ydata).*dspa'))/(sig^2);
      hllf(2:4,1)=hllf(1,2:4)';
      hllf(2:4,2:4)=hllf(2:4,2:4)/sig;
    end

    if (nargout > 3)
      im=gradmat'*gradmat/(sig^2);
    end

  else  % in this branch theta is 5x1 and theta(1) is the 2nd hidden layer bias and theta(2) is the weight on the input to the 2nd layer

    [spa,dspa,hspa]=learning_how_to_learn.subjective_posterior_prob(xdata,pa,pb,draws,theta(3:5),model);
   
    % cpa=1./(1+exp((theta(1)+theta(2)*spa)));  % compute binary logit probability of selecting the first alternative, 
    %                                             i.e. bingo cage A in this example
    %
    % Note: to improve numerical stability and accuracy, we do not actually evaluate pa via the formula above. Instead we split observations
    %       into those where the subjective probability is above 1/2 and those where it is below 1/2 and evaluate them separately to avoid
    %       loss of accuracy or program bombing due to possible overflow from evaluating (1-2*pa)/sigma if it takes on large positive values 
    %       Thus, we do not use the obvious way to write the log likelihood below
    %       llf=-sum(ydata.*logpa+(1-ydata).*log1mpa);
    %       and instead evaluate in a mathematically equivalent but numerically stable way below

    cpa=zeros(nobs,1);
    logsum=zeros(nobs,1);
    nspa=theta(1)+theta(2)*spa;
    ind=find(spa<0);
    indc=find(spa>=0);
    if (numel(ind))
       cpa(ind)=1./(1+exp(nspa(ind)));
       logsum(ind)=log(1+exp(nspa(ind)));
    end
    if (numel(indc))
       cpa(indc)=exp(-nspa(indc))./(1+exp(-nspa(indc)));
       logsum(indc)=nspa(indc)+log(1+exp(-nspa(indc)));
    end
    llf=sum(logsum)-sum((1-ydata).*nspa);
                                     
    if (nargout > 1)
      gradmat=zeros(nobs,5);
      gradmat(:,1)=(ydata-cpa);
      gradmat(:,2)=(ydata-cpa).*spa;
      gradmat(:,3:5)=theta(2)*(ydata-cpa).*dspa';
      dllf=sum(gradmat)';
    end
 
    if (nargout > 2)
      hllf=zeros(5,5);
      hllf(1,1)=sum(cpa.*(1-cpa));
      hllf(2,2)=sum(cpa.*(1-cpa).*spa.*spa);
      hllf(1,2)=sum(cpa.*(1-cpa).*spa);
      hllf(2,1)=hllf(1,2);
      for i=1:nobs
        hllf(3:5,3:5)=hllf(3:5,3:5)+theta(2)*((ydata(i)-cpa(i))*hspa(:,:,i)+theta(2)*cpa(i)*(1-cpa(i))*dspa(:,i)*(dspa(:,i)'));
      end
      hllf(2,3:5)=sum((ydata-cpa).*dspa'+theta(2)*cpa.*(1-cpa).*spa.*dspa');
      hllf(3:5,2)=hllf(2,3:5)';
      hllf(1,3:5)=theta(2)*sum(cpa.*(1-cpa).*dspa');
      hllf(3:5,1)=hllf(1,3:5)'; 
    end

    if (nargout > 3)
      im=gradmat'*gradmat;
    end

  end

 end

 function [cpa]=structural_ccp(xdata,pa,pb,draws,theta)

 % This function the "structural" binary logit conditional choice probability of choosing cage A given xdata (number n balls, prior) for 4x1 structural parameters theta
 % We assume that the subject choice is based on a "noisy subjective probability" of choosing cage A and so the subject chooses cage A
 % when the total utility of choosing it is higher, calculated as the sum of the subjective probability that cage A is the chosen cage 
 % plus an extreme value shock indexed by the parameter sigma.  This model nested the perfect Bayes Rule decision rule when sigma=0
 % when the parameters of the subjective choice model are (beta0,beta1,beta2)=(0,-1,-1). theta=(sigma,beta0,beta1,beta2).

 % outputs:
 % structural_ccp is the nobsx1 vector of structural probabilities of choosing cage A implied by parameters theta for data in xdata

 % inputs:
 % xdata is a matrix with nobs rows and 2 columns, where the first column contains n the number of balls drawn marked N and 2nd column is the prior prob of drawing cage A
 % pa    is a vector with nobs rows and 1 column, equaling the fraction of N balls in cage A
 % pb    is a vector with nobs rows and 1 column, equaling the fraction of N balls in cage B
 % draws is a vector with nobs rows and 1 column, equaling the number of balls drawn (with replacement) from the chosen cage
 % theta is a 4x1 vector of structural parameters where theta(1) is the sigma scaling or noise parameter

 nobs=size(xdata,1);

 sig=theta(1);
 [spa,dspa]=learning_how_to_learn.subjective_posterior_prob(xdata,pa,pb,draws,theta(2:4),'llr_lpr');

 % cpa=1./(1+exp((1-2*spa)/sigma));  % compute binary logit probability of selecting the first alternative, i.e. bingo cage A in this example
 %
 % Note: to improve numerical stability and accuracy, we do not actually evaluate pa via the formula above. Instead we split observations
 %       into those where the subjective probability is above 1/2 and those where it is below 1/2 and evaluate them separately to avoid
 %       loss of accuracy or program bombing due to possible overflow from evaluating (1-2*pa)/sigma if it takes on large positive values 
 %       Thus, we do not use the obvious way to write the log likelihood below
 %       llf=-sum(ydata.*logpa+(1-ydata).*log1mpa);
 %       and instead evaluate in a mathematically equivalent but numerically stable way below

 if (sig == 0)
    cpa=1*(spa>=1/2); 
    if (sum(pa == ydata)==nobs)
      llf=nobs;
    else
      llf=-log(0);
    end
 else 
    cpa=zeros(nobs,1);
    logsum=zeros(nobs,1);
    nspa=(1-2*spa)/sig;
    ind=find(spa>1/2);
    indc=find(spa<=1/2);
    if (numel(ind))
      cpa(ind)=1/(1+exp((1-2*spa(ind))/sig));
      logsum(ind)=log(1+exp(nspa(ind)));
    end
    if (numel(indc))
      cpa(indc)=exp(-nspa(indc))./(1+exp(-nspa(indc)));
      logsum(indc)=nspa(indc)+log(1+exp(-nspa(indc)));
    end
 end

 end

 function [llf,dllf,hllf,im]=blogit(ydata,xdata,pa,pb,draws,theta,model)

 % This function can be regarded as computing the log-likelihood function for a "reduced form" logit model of subject choices.
 % See structural_blogit function for a structural binary logit log-likelihood function with 4 parameters: the 3 parameters
 % entering the subjective_posterior_prob function plus a noise scale parameter sigma indexing the random "errors" in making a decision.
 % This function computes the log-likelihood (llf), gradients of the log-likeihood (dllf) and hessian of the log-likelihood (hllf)
 % for a 3 parameter binary logit model given binary 0/1 dependent variable ydata and x variables in xdata
 % model is a string indicating the specification: currently either 'prior_as_log_odds' or 'prior_linearly' or 'llr_plr'
 % In all cases we add a constant term, and the case prior_as_log_odds and prior_linearly the first column of xdata 
 % (before we add the constant) contains n the number of balls marked 'N; in the El-Gamal and Grether experiment.
 % When model is 'prior_as_log_odds' the second column contains log(1-prior)-log(prior) (the negative log-prior odds)
 % When model is 'prior_linearly' the second column is just the prior, entered linearly in the specification
 % When model is 'llr_lpr' the first column of xdata is assumed to contain log(f(n|A)/f(n|B)), the log-likelihood ratio
 % for drawing from cage A versus drawing from cage B, and the 2nd column of xdata contains log(prior/(1-prior)), the
 % log prior odds ratio. 

 % inputs:
 % ydata is a nobsx1 vector with the chosen cage of the subject, with ydata=1 if the subject chose cage A and ydata=0 if the subject chose cage B
 % xdata is a matrix with nobs rows and 2 columns, where the first column contains n the number of balls drawn marked N and 2nd column is the prior prob of drawing cage A
 % pa    is a vector with nobs rows and 1 column, equaling the fraction of N balls in cage A
 % pb    is a vector with nobs rows and 1 column, equaling the fraction of N balls in cage B
 % draws is a vector with nobs rows and 1 column, equaling the number of balls drawn (with replacement) from the chosen cage
 % theta is a 4x1 vector of structural parameters where theta(1) is the sigma scaling or noise parameter

 % outputs:
 % llf is the log-likelihood function
 % dllf is the gradient of log-likelihood function with respect to the 3 model parameters theta
 % hllf is the 3x3 hessian matrix of the log-likelihood with respect to the 3 model parameters theta
 % im is the 3x3 information matrix of the log-likelihood: the outer-product of the gradients with respect to the 3 model parameters theta

 nobs=size(xdata,1);

 prior=xdata(:,2);
 if (strcmp(model,'llr_lpr'))   

    % recode the first column of xdata as the log-likeihood ratio log(f(n|A)/f(n|B)) not n
    xdata(:,1)=log(binopdf(xdata(:,1),draws,pa))-log(binopdf(xdata(:,1),draws,pb));

    % recode the second column of xdata as the log prior odds ratio
    xdata(:,2)=log(prior)-log(1-prior);

 end

 if (strcmp(model,'prior_as_log_odds'))
 xdata(:,2)=log(1-prior)-log(prior);  % negative of prior log odds in last column of x matrix
 end
 
 xdata=[ones(nobs,1) xdata];  % add a constant term

 xtheta=xdata*theta;
 cpa=1./(1+exp(xtheta));  % compute binary logit probability of selecting the first alternative, i.e. bingo cage A in this example

 logpa=log(cpa);
 isinfpa=isinf(logpa);
 logpa(isinfpa)=-750;

 log1mpa=log(1-cpa);
 isinf1mpa=isinf(log1mpa);
 log1mpa(isinf1mpa)=-750;
 
 llf=-sum(ydata.*logpa+(1-ydata).*log1mpa);

 if (nargout > 1)
 dllf=-sum(xdata.*(cpa-ydata));
 end

 if (nargout > 2)
 hllf=((1-cpa).*xdata)'*(cpa.*xdata);
 end

 if (nargout > 3)
 im=(xdata.*(cpa-ydata));
 im=im'*im;
 end

 end

 function [llf,dllf,hllf,im]=bprobit(ydata,xdata,pa,pb,draws,theta,model)

 % computes the log-likelihood (llf), gradients of the log-likeihood (dllf) and hessian of the log-likelihood (hllf)
 % for the binary probit model given binary 0/1 dependent variable ydata and x variables in xdata
 % model is a string indicating the specification: currently either 'prior_as_log_odds' or 'prior_linearly' or 'llr_plr'
 % In all cases we add a constant term, and the case prior_as_log_odds and prior_linearly the first column of xdata 
 % (before we add the constant) contains n the number of balls marked 'N; in the El-Gamal and Grether experiment.
 % When model is 'prior_as_log_odds' the second column contains log(1-prior)-log(prior) (the negative log-prior odds)
 % When model is 'prior_linearly' the second column is just the prior, entered linearly in the specification
 % When model is 'llr_lpr' the first column of xdata is assumed to contain log(f(n|A)/f(n|B)), the log-likelihood ratio
 % for drawing from cage A versus drawing from cage B, and the 2nd column of xdata contains log(prior/(1-prior)), the
 % log prior odds ratio

 % inputs:
 % ydata is a nobsx1 vector with the chosen cage of the subject, with ydata=1 if the subject chose cage A and ydata=0 if the subject chose cage B
 % xdata is a matrix with nobs rows and 2 columns, where the first column contains n the number of balls drawn marked N and 2nd column is the prior prob of drawing cage A
 % pa    is a vector with nobs rows and 1 column, equaling the fraction of N balls in cage A
 % pb    is a vector with nobs rows and 1 column, equaling the fraction of N balls in cage B
 % draws is a vector with nobs rows and 1 column, equaling the number of balls drawn (with replacement) from the chosen cage
 % theta is a 4x1 vector of structural parameters where theta(1) is the sigma scaling or noise parameter

 % outputs:
 % llf is the log-likelihood function
 % dllf is the gradient of log-likelihood function with respect to the 3 model parameters theta
 % hllf is the 3x3 hessian matrix of the log-likelihood with respect to the 3 model parameters theta
 % im is the 3x3 information matrix of the log-likelihood: the outer-product of the gradients with respect to the 3 model parameters theta

 nobs=size(xdata,1);

 prior=xdata(:,2);
 if (strcmp(model,'llr_lpr'))  

    % recode the first column of xdata as the log-likeihood ratio log(f(n|A)/f(n|B)) not n
    xdata(:,1)=log(binopdf(xdata(:,1),draws,pa))-log(binopdf(xdata(:,1),draws,pb));

    % recode the second column of xdata as the log prior odds ratio
    xdata(:,2)=log(prior)-log(1-prior);

 end

 if (strcmp(model,'prior_as_log_odds'))
 xdata(:,2)=log(1-prior)-log(prior);  % negative of prior log odds in last column of x matrix
 end
 
 xdata=[ones(nobs,1) xdata];  % add a constant term

 xtheta=xdata*theta;
 cpa=cdf('norm',xtheta,0,1);  % compute binary probit probability of selecting the first alternative, i.e. bingo cage A in this example

 llf=-sum(ydata.*log(cpa)+(1-ydata).*log(1-cpa));

 if (nargout > 1)
   pdftheta=pdf('norm',xtheta,0,1);
   dllf=-sum(xdata.*(ydata.*(pdftheta./cpa)-(1-ydata).*(pdftheta./(1-cpa))));
 end

 if (nargout > 2)
   hllf=zeros(3,3);
   for i=1:nobs
     ratio=pdftheta(i)/cpa(i);
     ratio1=pdftheta(i)/(1-cpa(i));
     hllf=hllf+(xdata(i,:)*xdata(i,:)')*((ratio^2+ratio*xtheta(i))*ydata(i)-(1-ydata(i))*(ratio1*xtheta(i)+ratio1^2));
   end
 end

 if (nargout > 3)
   im=(xdata.*(ydata.*(pdftheta./cpa)-(1-ydata).*(pdftheta./(1-cpa))));
   im=im'*im;
 end


 end

 function [llf,dllf,hllf,typecount]=mixed_blogit(ycdata,xcdata,pca,pcb,cdraws,theta,ntypes,model)

 % Computes the log-likelihood (llf), gradients of the log-likeihood (dllf) and hessian of the log-likelihood (hllf)
 % for the mixed binary logit model with ntypes types of individuals who have different choice/response probabilities 
 % given by type-specific binary logit models with 1/0 dependent variable ydata and x variables in xdata
 % model is a string indicating the specification: currently either 'prior_as_log_odds' or 'prior_linearly' or 'llr_plr'
 % In all cases we add a constant term, and the case prior_as_log_odds and prior_linearly the first column of xdata 
 % (before we add the constant) contains n the number of balls marked 'N; in the El-Gamal and Grether experiment.
 % When model is 'prior_as_log_odds' the second column contains log(1-prior)-log(prior) (the negative log-prior odds)
 % When model is 'prior_linearly' the second column is just the prior, entered linearly in the specification
 % When model is 'llr_lpr' the first column of xdata is assumed to contain log(f(n|A)/f(n|B)), the log-likelihood ratio
 % for drawing from cage A versus drawing from cage B, and the 2nd column of xdata contains log(prior/(1-prior)), the
 % log prior odds ratio
 %
 % Thus after adding a constant, xdata always has 3 columns and thus 3 coefficients per type.
 % With ntypes then theta has 3*ntypes+ntypes-1 elements, so the first ntypes-1 coefficients determine the probabilities
 % of the ntypes of individuals in the population, and the reamining 3*ntypes elements are the 3x1 coefficient vectors
 % for each of the ntypes types, stacked in order, from type 0, 1,...,ntypes-1. The first ntypes-1 coefficients are
 % logit coefficients for types 1,...,ntypes-1 where for type j, the probability is p_j=exp(theta_j)/(1+\sum_{j'=1}^{ntypes-1} exp(theta_j'})
 % and thus (theta_1,theta_2,...theta_{ntypes-1}) determine fhe fractions of each type in the population

 dim_theta=size(theta,1);

 typeprobs=exp(theta(1:ntypes-1)); 
 typeprobs=[1 typeprobs']'./(1+sum(typeprobs));

 theta=reshape(theta(ntypes:end),3,ntypes);

 nsubjects=size(ycdata,2);

 llf=0;
 dllf=zeros(dim_theta,1);
 hllf=zeros(dim_theta,dim_theta);

 for subject=1:nsubjects

   ydata=ycdata{subject};
   xdata=xcdata{subject};
   pa=pca{subject};
   pb=pcb{subject};
   draws=cdraws{subject};
   nobs=size(ydata,1);

   prior=xdata(:,2);

   if (strcmp(model,'prior_as_log_odds'))
     xdata(:,2)=log(1-prior)-log(prior);  % prior log odds in last column of x matrix
   end

   if (strcmp(model,'llr_lpr'))  

    % recode the first column of xdata as the log-likeihood ratio log(f(n|A)/f(n|B)) not n
    xdata(:,1)=log(binopdf(xdata(:,1),draws,pa))-log(binopdf(xdata(:,1),draws,pb));

    % recode the second column of xdata as the log prior odds ratio
    xdata(:,2)=log(prior)-log(1-prior);

   end
 
   xdata=[ones(nobs,1) xdata];  % add a constant term

   xtheta=xdata*theta;
   cpa=1./(1+exp(xtheta));  % compute binary logit probability of selecting the first alternative, i.e. bingo cage A in this example

   mpa=cpa*typeprobs;
   logpa=log(mpa);
   log1mpa=log(1-mpa);
 
   subject_llf=-sum(ydata.*logpa+(1-ydata).*log1mpa);
   llf=llf+subject_llf;

   if (nargout > 1)
     dllf=zeros(3*ntypes,1);
   end

   if (nargout > 2)
     hllf=zeros(3*ntypes,3*ntypes);
   end

 end

 end

 function [llf,dllf,hllf,im,typecount]=ec_structural_logit(ycdata,xcdata,pca,pcb,cdraws,theta,ntypes)

 % EC (estimation-classification) likelihood function. Similar to mixed_blogit function except for each person, the
 % function evaluates the person-specific likelihood contribution over the different types of individuals and picks
 % as the likelihood contribution the type with the highest person-specific likelihood.  Also returns the number of
 % observations in each category, so as a fraction of all subjects, these are analogous to the mixture weights in mixed_blogit.
 % In this function ydata and xdata are cell arrays, with each element containing the person-specific ydata and xdata matrices.
 % In all cases we add a constant term, and the case prior_as_log_odds and prior_linearly the first column of xdata 
 % (before we add the constant) contains n the number of balls marked 'N; in the El-Gamal and Grether experiment.
 %
 % Thus after adding a constant, xdata always has 4 columns and thus 4 coefficients per type.
 % With ntypes then theta has 4*ntypes elements.

 if (ntypes == 1)

    % in a single type model no need to choose subject-specific best types, so just do a single call to
    % structural_blogit to maximize the likelihood of single type model. Remember to reconstitute cell arrays as ordinary matrices 
    % before calling structural_blogit

    nsubjects=numel(ycdata);
    xdata=[];
    ydata=[];
    pa=[];
    pb=[];
    draws=[];
    for i=1:nsubjects
       xdata=[xdata; xcdata{i}];
       ydata=[ydata; ycdata{i}];
       pa=[pa; pca{i}];
       pb=[pb; pcb{i}];
       draws=[draws; cdraws{i}];
    end
    [llf,dllf,hllf,im]=learning_how_to_learn.structural_blogit(ydata,xdata,pa,pb,draws,theta);
    typecount=[nsubjects];

 else

   theta=reshape(theta,4,ntypes);

   nsubjects=size(ycdata,2);

   llf=0;
   dllf=zeros(4*ntypes,1);
   hllf=zeros(4*ntypes,4*ntypes);
   im=zeros(4*ntypes,4*ntypes);
   typecount=zeros(ntypes,1);

   for subject=1:nsubjects

     ydata=ycdata{subject};
     xdata=xcdata{subject};
     pa=pca{subject};
     pb=pcb{subject};
     draws=cdraws{subject};

     for typ=1:ntypes
       [llft,dllft,hllft]=learning_how_to_learn.structural_blogit(ydata,xdata,pa,pb,draws,theta(:,typ)); 
       if (typ == 1)
         llf_opt=llft;
         ind=typ;
         dllf_opt=dllft;
         hllf_opt=hllft;
       else
         if (llft < llf)
           llf_opt=llft;
           ind=typ;
           dllf_opt=dllft;
           hllf_opt=hllft;
         end
       end
     end

     llf=llf+llf_opt;

     typecount(ind)=typecount(ind)+1;

     if (nargout > 1)
       subject_dllf=zeros(4*ntypes,1);
       subject_dllf(4*(ind-1)+1:4*ind)=dllf_opt;
       dllf=dllf+subject_dllf;
     end

     if (nargout > 2)
       im=im+subject_dllf*subject_dllf';
       subject_hllf=zeros(4*ntypes,4*ntypes);
       subject_hllf(4*(ind-1)+1:4*ind,4*(ind-1)+1:4*ind)=hllf_opt;
       hllf=hllf+subject_hllf;
     end

   end % end of for loop over subjects

 end % end of if  ntypes == 1 branch

 end

 function [llf,dllf,hllf,typecount]=ec_blogit(ycdata,xcdata,pca,pcb,cdraws,theta,ntypes,model)

 % EC (estimation-classification) likelihood function. Similar to mixed_blogit function except for each person, the
 % function evaluates the person-specific likelihood contribution over the different types of individuals and picks
 % as the likelihood contribution the type with the highest person-specific likelihood.  Also returns the number of
 % observations in each category, so as a fraction of all subjects, these are analogous to the mixture weights in mixed_blogit.
 % In this function ydata and xdata are cell arrays, with each element containing the person-specific ydata and xdata matrices.
 % In all cases we add a constant term, and the case prior_as_log_odds and prior_linearly the first column of xdata 
 % (before we add the constant) contains n the number of balls marked 'N; in the El-Gamal and Grether experiment.
 % When model is 'prior_as_log_odds' the second column contains log(1-prior)-log(prior) (the negative log-prior odds)
 % When model is 'prior_linearly' the second column is just the prior, entered linearly in the specification
 % When model is 'llr_lpr' the first column of xdata is assumed to contain log(f(n|A)/f(n|B)), the log-likelihood ratio
 % for drawing from cage A versus drawing from cage B, and the 2nd column of xdata contains log(prior/(1-prior)), the
 % log prior odds ratio
 %
 % Thus after adding a constant, xdata always has 3 columns and thus 3 coefficients per type.
 % With ntypes then theta has 3*ntypes elements.

 theta=reshape(theta,3,ntypes);

 nsubjects=size(ycdata,2);

 llf=0;
 dllf=zeros(3*ntypes,1);
 hllf=zeros(3*ntypes,3*ntypes);
 typecount=zeros(ntypes,1);

 for subject=1:nsubjects

   ydata=ycdata{subject};
   xdata=xcdata{subject};
   pa=pca{subject};
   pb=pcb{subject};
   draws=cdraws{subject};
   nobs=size(ydata,1);
   prior=xdata(:,2);

   if (strcmp(model,'prior_as_log_odds'))
     xdata(:,2)=log(1-prior)-log(prior);  % prior log odds in last column of x matrix
   end

   if (strcmp(model,'llr_lpr'))

    % recode the first column of xdata as the log-likeihood ratio log(f(n|A)/f(n|B)) not n
    xdata(:,1)=log(binopdf(xdata(:,1),draws,pa))-log(binopdf(xdata(:,1),draws,pb));

    % recode the second column of xdata as the log prior odds ratio
    xdata(:,2)=log(prior)-log(1-prior);

   end
 
   xdata=[ones(nobs,1) xdata];  % add a constant term

   xtheta=xdata*theta;
   cpa=1./(1+exp(xtheta));  % compute binary logit probability of selecting the first alternative, i.e. bingo cage A in this example

   logpa=log(cpa);
   log1mpa=log(1-cpa);
 
   llft=-sum(ydata.*logpa+(1-ydata).*log1mpa);
   mllft=min(llft);
   llf=llf+mllft;

   ind=find(mllft==llft);
   typecount(ind)=typecount(ind)+1;

   if (nargout > 1)
     subject_dllf=zeros(3*ntypes,1);
     subject_dllf(3*(ind-1)+1:3*ind)=-sum(xdata.*(cpa(ind)-ydata));
     dllf=dllf+subject_dllf;
   end

   if (nargout > 2)
     hllf=zeros(3*ntypes,3*ntypes);
   end

 end

 end

 function [ydata,xdata]=generate_training_data(ntrain,pa,pb,nballs,dependent_variable)

 % inputs: ntrain      integer size of the "training sample" to generate to train the machine learning algorithm.  
 %                     This will result in random samples (with replacement) from the selected cage, where the cage A
 %                     is selected with probability pi where pi is a random uniform number, U(0,1). Given the case, we use
 %                     a random draw from a binomial distribution with parameters nballs (number of balls in each cage) and
 %                     either pa or pb (depending on whether cage A or B was selected on realization i of the simulation) and
 %                     the resulting simulated value of n(i) (an integer from 0 to nballs) is stored in xdata(i,1) and the 
 %                     random U(0,1) prior is stored in xdata(i,2). A dependent variable ydata(i) is generated and equal to 1
 %                     if a random uniform draw is less than xdata(i,2) where the latter is the randomly generated prior probability
 %                     of selecting cage A to draw the sample.
 % pa                  fixed probability of drawing a ball labelled N from cage A
 % pb                  fixed probability of drawing a ball labelled N from cage B
 % nballs              an integer for the binomial parameter n, interpreted as the total number of balls in the cage. However
 %                     we allow pa and pb to be any number between 0 and 1, which will not be the case if pa is the fraction of
 %                     balls marked N and 1-pa is the fraction of balls marked G in a given cage with nballs balls in it. These
 %                     fractions would be restricted to the n+1 values pa=(0,1/nballs,...,(nballs-1)/nballs,1) if the probabilities
 %                     would correspond to randomly selecting balls from a cage with replacement. Similar comments hold for cage B.
 %                     
 % dependent_variable  a string that equals either `true_classification' or else 'bayes_rule_classification'
 %                     where the former (the default return from generate_taining_data) is the actual bingo cage that was selected
 %                     whereas bayes_rule_classification is the cage that a perfect bayesian decision maker would select 
 %                     after observing xdata and calculating the true Bayesian posterior probability of cage A.

 % outputs: 
 %
 % ydata a vector (ntrain x 1) equal to 1 if bingo cage A was used to draw the sample of balls with replacement, or 
 %                                      0 if drawn from B if dependent_variable is set to `true_classification' otherwise 
 %       it equals 0 if the posterior probability of A is less than 1/2 and 1 otherwise when dependent_variable is 
 %       'bayes_rule_classification' and if the dependent_variable is 'noisy Bayesian' it equals 1 with probability P(A|n,pi),
 %       is the true Bayes Rule posterior, and 0 otherwise.
 %
 % xdata a matrix (ntrain x 2) whose first column contains n, the number of balls marked with an N from the selected bingo cage   
 %                             and the 2nd column is the randomly simulated U(0,1) prior probability of drawing from cage A

 xdata=zeros(ntrain,2);  % the data consist of the number of balls marked N that were drawn and the prior probability
                         % used to draw the sample
 ydata=zeros(ntrain,1);  % the ydata is the "dependent variable" d, showing which cage the sample was drawn from

 xdata(:,2)=rand(ntrain,1);  % here we randomly generate uniform(0,1) random numbers to be the prior probabilities used
                             % to train the machine 
   for i=1:ntrain

     % first we select the bingo cage, according to the true model using the prior probability stored in xdata(i,2)
 
     ydata(i)=(rand(1,1)<=xdata(i,2));  % if this is 1 then use cage A to draw the number of balls marked N from, otherwise
                                        % draw from cage B 

     % then given the chosen bingo cage, we generate a draw from it representing the result of drawing nballs with replacement

     if (ydata(i))
       xdata(i,1)=binornd(nballs,pa,1);
     else
       xdata(i,1)=binornd(nballs,pb,1);
     end

     % finally we redefine the dependent variable if the dependent_variable is set to bayes_rule_classification

     if (strcmp(dependent_variable,'bayes_rule_classification') | strcmp(dependent_variable,'noisy_bayes_rule'))

        % calculate the posterior probability given the prior in xdata(i,2) and number of N balls drawn in xdata(i,1)

        ppa=binopdf(xdata(i,1),nballs,pa)*xdata(i,2);
        den=ppa+binopdf(xdata(i,1),nballs,pb)*(1-xdata(i,2));
        ppa=ppa/den;

        ydata(i)=(ppa >= 1/2);

        if (strcmp(dependent_variable,'noisy_bayes_rule'))

           ydata(i)=(rand(1,1) <= ppa);

        end 

     end

   end  % end of do-loop to generate training data

 end % end of function generate_training_data 

 function [llf,ic,total_obs,total_subjects,err_rate]=eg_lf_singletype(cr,datastruct,school)

 % eg_lf_singletype.m: subject likelihood in the El-Gamal and Grether model with a single "type" (decision rule) and
 %                     common estimated error rate
 %                     John Rust, Georgetown University, February, 2022
 %
 % Inputs:
 %
 % cr  a 3x1 vector of integer cutoffs: when there is no error, subject chooses cage A if number of N's under prior i (i=1,2,3)
 %     exceeds cr(i)
 % datastruct an array of structures holding the results for different experiments
 % school  a string variable that is empty, '', to evaluate for all schools, or a school abbreviation ('CSULA','OXY','UCLA','PCC')
 %         if you want to restrict the evaluation of the likelihood to only subjects of specific schools (see Table 2 of El-Gamal and Grether, 1995)


    numexps=numel(datastruct);
    llf=0;
    llf_homo=0;
    total_consistent=0;
    total_obs=0;
    total_subjects=0;

    k=size(cr,1);

    if (numexps > 7)    % fix this later to account for Wisconsin experiments in datastruct (elements 8,9,10,11)
       numexps=7;
    end


    for e=1:numexps;    % loop over all experiments to calculate likelihood
      if (startsWith(datastruct(e).name,school) | strcmp(school,''))    % if the school string is provided, then likelihood is calculated for given school
        nsubjects=size(datastruct(e).subjectchoices,1);
        priors=datastruct(e).priors;
        ntrials=numel(priors);
        ndraws=datastruct(e).ndraws;
        cr_prior=cr(priors-1)';  % trial specific cutoff depending on the prior in that trial
        cr_choice=(ndraws > cr_prior)';  % predicted choices for each trial implied by the cutoff rule
        consistent_obs=sum((cr_choice == datastruct(e).subjectchoices)');
        err_rates=2*(1-sum(consistent_obs)/(nsubjects*ntrials));

        total_subjects=total_subjects+nsubjects;
        total_consistent=total_consistent+sum(consistent_obs);
        total_obs=total_obs+nsubjects*ntrials;

        llf=llf+sum(consistent_obs.*log(1-err_rates/2)+(ntrials-consistent_obs).*log(err_rates/2));
      end
    end

    err_rate=2*(1-total_consistent/total_obs);

    llf=total_consistent*log(1-err_rate/2)+(total_obs-total_consistent)*log(err_rate/2);

    ic=llf-3*k*log(8)-k*log(2)-total_subjects*log(k);

 end % end of function eg_lf_singletype
      
 function [tllf,total_obs,total_subjects,err_rates,cutoffs,maxinfo,maxcutoffs]=eg_fixed_effects(datastruct,school)

 % eg_fixed_effects.m: fixed effects estimation of the El-Gamal and Grether model: each subject is assigned the maximum 
 %                     likelihood cutoff rule and error rate that maximizes the subject-specific likelihood
 %                     Note: to speed up the estimation, we only search over a subset of the 512 possible cutoff rules where
 %                     each cutoff (c1,c2,c3) is restricted to be an integer from 1 to 5
 %                     John Rust, Georgetown University, February, 2022
 %
 % Inputs:
 %
 % datastruct an array of structures holding the results for different experiments
 % school  a string variable that is empty, '', to evaluate for all schools, or a school abbreviation ('CSULA','OXY','UCLA','PCC')
 %         if you want to restrict the evaluation of the likelihood to only subjects of specific schools (see Table 2 of El-Gamal and Grether, 1995)

    numexps=numel(datastruct);
    tllf=0;
    total_obs=0;
    total_subjects=0;
    err_rates=[];
    cutoffs=[];
    crlist=[];
    maxcutoffs=[];
    maxinfo=struct;

    for c1=-1:6
     for c2=-1:6
      for c3=-1:6
        crlist=[crlist; [c1 c2 c3]];
      end
     end
    end

    ncr=size(crlist,1);
    sc=0;

    for e=1:numexps;    % loop over all experiments to calculate likelihood
      if (startsWith(datastruct(e).name,school) | strcmp(school,''))    % if the school string is provided, then likelihood is calculated for given school

        nsubjects=size(datastruct(e).subjectchoices,1);
        priors=datastruct(e).priors;
        ntrials=numel(priors);
        ndraws=datastruct(e).ndraws;
        total_subjects=total_subjects+nsubjects;
        total_obs=total_obs+nsubjects*ntrials;

        for i=1:nsubjects

         sc=sc+1;
         llv=zeros(ncr,1);

         for r=1:ncr

           cr=crlist(r,:);
           cr_prior=cr(priors-1)';  % trial specific cutoff depending on the prior in that trails
           cr_choice=(ndraws > cr_prior)';  % predicted choices for each trial implied by the cutoff rule
           consistent_obs=sum((cr_choice == datastruct(e).subjectchoices(i,:)));
           err_rate=min(1,2*(1-sum(consistent_obs)/ntrials));
           llf=sum(consistent_obs*log(1-err_rate/2)+(ntrials-consistent_obs)*log(err_rate/2));
           llv(r)=llf;

           if (r == 1)
              mll=llf;
              bestcr=cr;
              best_err_rate=err_rate;
           else
              if (llf > mll)
                mll=llf;
                bestcr=cr;
                best_err_rate=err_rate;
              end
           end

         end
    
         fprintf('Experiment %i ntrials %i subject %i  llf=%g  err_rate=%g cr=(%i,%i,%i)\n',e,ntrials,i,mll,best_err_rate,bestcr);
         tllf=tllf+mll;
         err_rates=[err_rates; best_err_rate];
         cutoffs=[cutoffs; bestcr];
         nmax=sum(llv==mll);
         maxinfo(sc).nmax=nmax;
         maxinfo(sc).optcutoffs=crlist(find(llv==mll),:);
         maxcutoffs=[maxcutoffs; maxinfo(sc).optcutoffs];

        end
      end
    end

 end % end of function eg_lf_singletype
      
 function [llf,ic,total_obs,classified_subjects]=eg_lf_multitype(err_rate,cr,datastruct,school)

 % eg_lf_multitype.m: subject likelihood in the El-Gamal and Grether model with a single "type" (decision rule) and
 %                    common estimated error rate
 %                     John Rust, Georgetown University, February, 2022
 %
 % Inputs:
 %
 % err_rate a scalar common probability of "deviating" and randomly choosing an annswer that we assume all subjects are doing
 % cr  a kx3 matrix of integer cutoffs: when there is no error, subject chooses cage A if number of N's under prior i (i=1,2,3)
 %     exceeds cr(k,i) under cutoff rule k.
 % datastruct an array of structures holding the results for different experiments
 % school  a string variable that is empty, '', to evaluate for all schools, or a school abbreviation ('CSULA','OXY','UCLA','PCC')
 %         if you want to restrict the evaluation of the likelihood to only subjects of specific schools (see Table 2 of El-Gamal and Grether, 1995)
 
 % Outputs:
 % llf  the log likelihood from the EC algorithm evaluated at the error rate err_rate
 % ic   the information criteriof (see El-Gamal and Grether 1995 for its definition, but it is a penalized likelihood, penalized for number of parameters
 % total_obs total number of subject/trial observations
 % classified_subjects  a vector that is of length total_subjects x 1 that indexes the cutoff rule that best predicts the subject's choices
 
    numexps=numel(datastruct);
    total_consistent=0;
    total_obs=0;
    llf=0;
    classified_subjects=[];

    if (numexps > 7)  % fix me: add code to handle Wisconsin experiments which have different prior probabilities than California experiments
      numexps=7;
    end

    k=size(cr,1);

    for e=1:numexps;    % loop over all experiments to calculate likelihood
      if (startsWith(datastruct(e).name,school))    % if the school string is provided, then likelihood is calculated for given school

        nsubjects=size(datastruct(e).subjectchoices,1);
        priors=datastruct(e).priors;
        ntrials=numel(priors);
        ndraws=datastruct(e).ndraws;
        total_obs=total_obs+nsubjects*ntrials;
        llfm=zeros(k,nsubjects);

        for t=1:k  % this do loop is the core of the EC algorithm: it computes subject-specific likelihoods for each cutoff rule in cr
          cr_prior=cr(t,priors-1)';  % trial specific cutoff depending on the prior in each trials, for cutoff rule t
          cr_choice=(ndraws > cr_prior)';  % predicted choices for each trial implied by cutoff rule t
          consistent_obs=sum((cr_choice == datastruct(e).subjectchoices)');
          llfm(t,:)=(consistent_obs*log(1-err_rate/2)+(ntrials-consistent_obs)*log(err_rate/2))';
        end
        if (k > 1)
          mllf=max(llfm);  % now we check which cutoff rule has the highest subject-specific likelihood and assign that rule to the subjects
          [ii,j]=find(llfm==mllf);
          [c,ia,ic]=unique(j,'stable');  % this code is necessary in case of ties, then the find command will return all indices where llfm is maximized
                                         % so the unique command picks out the first index in the matrix llfm where the maximum is attained, i.e. when
                                         % there are cutoff rules that lead to the same likelihood, we classify the subjects with the cutoff rule with the
                                         % lowest index in the matrix of cutoffs, cr
          cs=ii(ia);                     % this is the index of the cutoff rule with the highest likelihood for each subject given the current err_rate
        else
          cs=ones(nsubjects,1);
          mllf=llfm;
        end
 %  The code below is a slower way to do the above, in a do loop over each column of the llfm matrix
 %        cs=zeros(nsubjects,1);
 %        for i=1:nsubjects
 %           cs(i)=find(llfm(:,i)==mllf(i),1); 
 %        end
 %[cs ii(ia)]
 %sum(cs ~= ii(ia))
        llf=llf+sum(mllf);
        classified_subjects=[classified_subjects; cs];
      end
    end
   
    total_subjects=numel(classified_subjects);
    ic=llf-3*k*log(8)-k*log(2)-total_subjects*log(k);
      
 end % end of function eg_lf_multitype

 function [mll,mic,err_rate]=estimate_onetype_eg_model(datastruct,subsample);

 % estimate_onetype_eg_model.m  estimates the single type subcase of the El Gamal and Grether model,
 %                              compare to table 2 top rows in their 1995 paper, "Are People Bayesian?" in JASA
 
 % note that the function [llf,ic,total_obs,total_subjects,err_rate]=eg_lf_singletype([c1 c2 c3],datastruct,subsample) 
 % calculates the log likelihood (llf), information criterion and the maximum likelihood pooled error rate for cutoff rule [c1 c2 c3]
 % where these are integers between -1 and 6 (see page 1139 of El Gamal and Grether for further explanation). The likelihood
 % routine returns the maximum likelihood estimate of the common error rate, err_rat, that all subbjects are presumed to behave
 % according to, in conjunction with the cutoff rule [c1 c2 c3] where the 3 values index the 3 possible priors (1/3,1/2,2/3) used
 % in the experiment. This program does a more localized discrete search for cutoffs from 1 to 5 and does it as a brute force
 % search in a simple do-loop.

   llv=zeros(125,1);
   icv=zeros(125,1);
   errv=zeros(125,1);
   i=0;

   for c1=1:5
     for c2=1:5
       for c3=1:5
           i=i+1;
           [llf,ic,total_obs,total_subjects,err_rate]=learning_how_to_learn.eg_lf_singletype([c1 c2 c3],datastruct,subsample);
           llv(i)=llf;
           icv(i)=ic;
           errv(i)=err_rate;
           if (i == 1)
              mll=llf;
              mic=ic;
              err_rate_best=err_rate;
              bestc=[c1 c2 c3];
              bestic=[c1 c2 c3];
           else
              if (llf > mll)
                mll=llf;
                err_rate_best=err_rate;
                bestc=[c1 c2 c3];
              end
              if (ic > mic)
                mic=ic;
                bestic=[c1 c2 c3];
              end
           end
           fprintf('%i searching (c1,c2,c3)=(%i,%i,%i) llf=%g ic=%g  best likelihood so far: %g best ic %g  error_rate=%g\n',i,c1,c2,c3,llf,ic,mll,mic,err_rate_best); 
       end
     end
   end
   if (strcmp(subsample,''))
     fprintf('\nSummary of maximum likelihood estimation of homogeneous cutoff rule using full El-Gamal and Grether California subject pool\n');
   else
     fprintf('\nSummary of maximum likelihood estimation of homogeneous cutoff rule using subsample of El-Gamal and Grether California subject pool located at %s\n',subsample);
   end
   fprintf('Highest log-likehood is %g\n',mll);
   fprintf('maximum likelihood estimate of error rate: %g  and maximum likelihood cutoff rule is:\n',err_rate_best);
   bestc

   fprintf('Highest IC value is %g and occurs for  cutoff rule:\n',mic);
   bestic

   fprintf('Total observations in all trials: %i   Total number of subjects in the trials: %i\n',total_obs,total_subjects);

   end  % end of function estimate_onetype_eg_model.m

 function [mll,bestcr,err_rate]=estimate_twotype_eg_model(datastruct,subsample);

 % estimate_twotype_eg_model.m  estimates the two type subcase of the El Gamal and Grether model via the EC algorithm
 %                              compare to table 2 second group of rows in their 1995 paper, "Are People Bayesian?" in JASA

 % Outputs:
 %
 % mll       maximized value of the log-likehood function
 % bestcr    optimal set of cutoff rules, i.e. the set of k cutoff rules that maximize the likelihood function 
 % err_rate  the uniform probability of doing 50/50 random choice of the two cages, common to all subjects for each cutoff rule
 
 % note that the function [llf,ic,total_obs,total_subjects,err_rate]=eg_lf_multitype(cr,datastruct,subsample) 
 % calculates the log likelihood (llf), information criterion and the maximum likelihood pooled error rate for cutoff rules in a matrix cr
 % which has k rows and 3 columns. Each row is a separate cutoff rule. This is done as a do-loop over all pairs of distinct 
 % cutoff rules that are "reasonable" where instead of searching over all 512 possible cutoff rules where the cutoffs are defined by triples 
 % of integers between -1 and 6 (see page 1139 of El Gamal and Grether for further explanation) this program searches over a smaller subject
 % where the cutoffs are restricted to integers between 1 and 5. The innermost call using fminbnd to calculate the maximum likelihood
 % likelihood estimate of the common error rate, err_rate, that all subjects are presumed to behave according to, after an inner most EC
 % algorithm has classified each subject according to the rule that has the highest likelihood for them given the current estimate of the error rate.

   llv=zeros(125,1);
   icv=zeros(125,1);
   errv=zeros(125,1);
   clist=[];
   i=0;

   for c1=1:5
     for c2=1:5
       for c3=1:5
           i=i+1;
           clist=[clist; [c1 c2 c3]];
       end
     end
   end

   % the order of rules does not matter and they must be distinct, so code below
   % creates an array of structures called cpairs that has 7750 distinct pairs of cutoff rules

   cpairs=struct;
   ccp=[];
   k=0;
   for i=1:125
     for j=1:125;
      if (i ~= j)
        if (numel(ccp))
          ind=find(sum(ccp == [clist(j,:)'; clist(i,:)'])==6);
          if (numel(ind) == 0)
            k=k+1;
            cpairs(k).cr=[clist(i,:); clist(j,:)];
            ccp=[ccp [clist(i,:)'; clist(j,:)']];
          end
        else
          k=k+1;
          cpairs(k).cr=[clist(i,:); clist(j,:)];
          ccp=[ccp [clist(i,:)'; clist(j,:)']];
        end
      end
     end
   end

   ncr=numel(cpairs);

   for i=1:ncr;

      [x,v]=fminbnd(@(x) -learning_how_to_learn.eg_lf_multitype(x,cpairs(i).cr,datastruct,subsample),0,1);

           err_rate=x;
           llf=-v;
           if (i == 1)
              mll=llf;
              err_rate_best=err_rate;
              bestcr=cpairs(i).cr;
           else
              if (llf > mll)
                mll=llf;
                err_rate_best=err_rate;
                bestcr=cpairs(i).cr;
              end
           end
           fprintf('%i cutoff pair (c1,c2,c3)=(%i,%i,%i) (b1,b2,b3)=(%i,%i,%i) llf=%g best likelihood so far: %g error_rate=%g\n',i,cpairs(i).cr(1,:),cpairs(i).cr(2,:),llf,mll,err_rate_best); 

   end

   fprintf('\nSearch completed over 7750 pairs of decision rules\n');
   fprintf('Maximized log-likelihood: %g Maximum likelihood error probability %g  Maximum likelihood cutoff pair is:\n',mll,err_rate_best);
   bestcr

  end  % end of function estimate_twotype_eg_model.m

end % methods

end % classdef
