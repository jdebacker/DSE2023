% check_ec_structural_logit_gradients.m  numerical check of analytical gradient and hessian of the function
%                                         ec_structural_blogit, which computes the log-likelihood function for the
%                                         EC estimation of the structural binary logit model of subject responses  in the learning_how_to_learn class
%                                         John Rust, Georgetown University February, 2022 

ndelta=1e-5;  % numerical delta for taking double sided difference approximations for superaccurate
              % numerical derivatives 

[ydata,xdata]=learning_how_to_learn.prepare_data(datastruct,'all_individual');
options=optimoptions('fminunc','FunctionTolerance',1e-10,'Display','iter','Algorithm','quasi-newton','SpecifyObjectiveGradient',false,'MaxFunctionEvaluations',10000);

truetheta=[0; -1; -1];
truetheta=[.1; truetheta];   % sigma noise parameter is the first element

ntypes=2;
theta=[truetheta; .5; .1; -2; -1.7];
nparms=size(theta,1);

[llf,dllf,hllf,typecount]=learning_how_to_learn.ec_structural_logit(ydata,xdata,theta,ntypes);
fprintf('checking gradients of structural binary logit log-likelihood function: %g with ntypes=%i  and %i parameters\n',llf,ntypes,nparms);

ndllf=zeros(nparms,1);
nhllf=zeros(nparms,nparms);

for i=1:nparms

  theta_u=theta;
  theta_u(i)=theta_u(i)+ndelta;
  [llfu,dllfu]=learning_how_to_learn.ec_structural_logit(ydata,xdata,theta_u,ntypes);

  theta_l=theta;
  theta_l(i)=theta_l(i)-ndelta;
  [llfl,dllfl]=learning_how_to_learn.ec_structural_logit(ydata,xdata,theta_l,ntypes);

  ndllf(i)=(llfu-llfl)/(2*ndelta);
  nhllf(i,:)=(dllfu-dllfl)'/(2*ndelta);

end

fprintf('Parameters\n');
truetheta'
fprintf('Analytical gradients\n');
dllf
fprintf('Numerical gradients\n');
ndllf
fprintf('Difference\n');
ndllf-dllf
fprintf('Analytical hessian\n');
hllf
fprintf('Numerical hessian\n');
nhllf
fprintf('Difference\n');
nhllf-hllf

