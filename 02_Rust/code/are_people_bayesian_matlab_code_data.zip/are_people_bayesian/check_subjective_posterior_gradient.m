% check_subjective_posterior_gradient.m  numerical check of analytical gradient and hessian of the function
%                                        subjective_posterior_prob in the learning_how_to_learn class
%                                        John Rust, Georgetown University February, 2022 

if (~exist('datastruct'))
  load('datastruct');
end

ndelta=1e-5;  % numerical delta for taking double sided difference approximations for superaccurate
              % numerical derivatives 

[ydata,xdata,pa,pb,draws]=learning_how_to_learn.prepare_data(datastruct,'PCCNO.pay');

model='llr_plr';

if (strcmp(model,'llr_lpr'))
   truetheta=[0; -1; -1];
else
   truetheta=[6*(log(1/2)-log(1/3)); -log(2); 1];
end


uxdata=unique([xdata pa pb draws],'rows');
nuxdata=size(uxdata,1);
all_dlldiffs=[];
all_hlldiffs=[];

for r=1:nuxdata;

[pa,dpa,hpa]=learning_how_to_learn.subjective_posterior_prob(uxdata(r,1:2),uxdata(r,3),uxdata(r,4),uxdata(r,5),truetheta,model);

fprintf('r=%i checking gradients of subjective_posterior_prob function evaluated a [n,prior]=[%i,%g], implied posterior prob of urn A: %g\n',r, uxdata(r,:),pa);

nparms=size(truetheta,1);

ndpa=zeros(nparms,1);
nhpa=zeros(nparms,nparms);

for i=1:nparms

  theta_u=truetheta;
  theta_u(i)=theta_u(i)+ndelta;
  [pu,dpu]=learning_how_to_learn.subjective_posterior_prob(uxdata(r,1:2),uxdata(r,3),uxdata(r,4),uxdata(r,5),theta_u,model);

  theta_l=truetheta;
  theta_l(i)=theta_l(i)-ndelta;
  [pl,dpl]=learning_how_to_learn.subjective_posterior_prob(uxdata(r,1:2),uxdata(r,3),uxdata(r,4),uxdata(r,5),theta_l,model);

  ndpa(i)=(pu-pl)/(2*ndelta);
  nhpa(i,:)=(dpu-dpl)/(2*ndelta);

end

fprintf('Parameters\n');
truetheta'
fprintf('Analytical gradients\n');
dpa
fprintf('Numerical gradients\n');
ndpa
fprintf('Difference\n');
ndpa-dpa
all_dlldiffs=[all_dlldiffs abs(ndpa-dpa)];
fprintf('Analytical hessian\n');
hpa
fprintf('Numerical gradients\n');
nhpa
fprintf('Difference\n');
nhpa-hpa
all_hlldiffs=[all_hlldiffs; abs(nhpa-hpa)];

end

fprintf('Max absolute error in gradients (numerical-analytical) for %i observations\n',nuxdata);
max(max(all_dlldiffs)')
fprintf('Max absolute error in hessians (numerical-analytical) for %i observations\n',nuxdata);
max(max(all_hlldiffs)')
