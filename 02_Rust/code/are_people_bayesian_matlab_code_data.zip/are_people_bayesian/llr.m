% LLR.M: program to do multidimensional interpolation/extrapolation
%        via local linear regression
%        John Rust, University of Maryland January, 2008

   function [result]=llr(pv,v,x);
%
%   Inputs:
%  
%   pv: point in R^k at which a function v is to be approximated
%   v:  nx1 vector of values of a function v evaluated at x
%   x:  nxk matrix of points at which v is evaluated
%
%   Output:
%
%   v(x):  interpolated value at point x
%
%   Note: n should be substantially larger than k   
%
%   Parameters:
%
%   wr:   set to 1 for weighted regression, where
%         observations further from p are downweighted
%         set to 0 for unweighted regression.
%
%   h:    bandwidth */
%

    n=size(x,1);
    d=size(x,2);
    sx=std(x);

    rp=size(pv,1);
    h=1.06/(size(v,1)^(.2)); 
    result=zeros(rp,1);

    for i=1:rp;

      wts=ones(n,1);

      for j=1:d;

       wts=wts.*exp(-0.5*(((x(:,j)-pv(i,j)).^2)/(h*h*sx(j)*sx(j))));

      end;

      nx=[wts x.*wts]; 
      ny=v.*wts;

      result(i)=[1 pv(i,:)]*(nx\ny);

    end;

