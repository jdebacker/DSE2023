% check_structural_blogit_gradients.m  numerical check of analytical gradient and hessian of the function
%                                      structural_blogit, which computes the log-likelihood function for the
%                                      structural binary logit model of subject responses  in the learning_how_to_learn class
%                                      John Rust, Georgetown University February, 2022 

ndelta=1e-5;  % numerical delta for taking double sided difference approximations for superaccurate
              % numerical derivatives 

if (~exist('datastruct'))
  load('datastruct');
end

if (~exist('structural_thetahat'))
  load('structural_thetahat');
end

[ydata,xdata,pa,pb,draws]=learning_how_to_learn.prepare_data(datastruct,'PCCNO.pay');

model='llr_lpr';

if (strcmp(model,'llr_lpr'))
   truetheta=[0; -1; -1];
else
   truetheta=[6*(log(1/2)-log(1/3)); -log(2); 1];
end

truetheta=[0; .1; truetheta];   % sigma noise parameter is the first element
%truetheta=structural_thetahat;

[llf,dllf,hllf,im]=learning_how_to_learn.structural_blogit(ydata,xdata,pa,pb,draws,truetheta);

fprintf('checking gradients of structural binary logit log-likelihood function: %g\n',llf);

nparms=size(truetheta,1);

ndllf=zeros(nparms,1);
nhllf=zeros(nparms,nparms);

for i=1:nparms

  theta_u=truetheta;
  theta_u(i)=theta_u(i)+ndelta;
  [llfu,dllfu]=learning_how_to_learn.structural_blogit(ydata,xdata,pa,pb,draws,theta_u);

  theta_l=truetheta;
  theta_l(i)=theta_l(i)-ndelta;
  [llfl,dllfl]=learning_how_to_learn.structural_blogit(ydata,xdata,pa,pb,draws,theta_l);

  ndllf(i)=(llfu-llfl)/(2*ndelta);
  nhllf(i,:)=(dllfu-dllfl)/(2*ndelta);

end

fprintf('Parameters\n');
truetheta'
fprintf('Analytical gradients\n');
dllf
fprintf('Numerical gradients\n');
ndllf
fprintf('Difference\n');
ndllf-dllf
fprintf('Analytical information matrix\n');
hllf
fprintf('Numerical hessian\n');
nhllf
fprintf('Difference\n');
nhllf-hllf

