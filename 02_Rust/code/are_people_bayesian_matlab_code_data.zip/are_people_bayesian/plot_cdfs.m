% plot_cdfs.m: plots a comparison of the standard Normal CDF and the standardized logistic CDF
%              John Rust, Georgetown University, February, 2021

x=(-5:.01:5)';

cdf_normal=cdf('norm',x,0,1);
cdf_logistic=1./(1+exp(-x));

figure(1);
hold on;
plot(x,cdf_normal,'r-','Linewidth',2);
plot(x,cdf_logistic,'b-','Linewidth',2);
legend('Standard normal CDF, N(0,1)','Standard logistic CDF, L(0,1)','Location','Northwest');
title('Standard Normal and Logistic CDFs');
xlabel('x');
ylabel(sprintf('CDF: $$F(x)=Pr\\{\\tilde X\\le x\\}$$'),'Interpreter','latex');
hold off;

% this part we see if we can represent the true posterior using a Gaussian logistic regression curve
% as per the discussion in the though questions we can translate this to a question of regressing
% the 3 beta coefficients for the X\beta representation on the inverse normal CDF of the true posterior
% and verifying that this regression results in a perfect fit: it not, then the true posterior distribution
% is not in the space of probabililty distributions ``spanned'' by the normal logistic regression specification

pa=2/3;  % probability of drawing a ball marked N from bingo cage A (4 N balls, 2 G balls)
pb=1/2;  % probability of drawing a ball marked N from bingo cage B (3 N balls, 3 G balls)
nballs=6;  % number of balls in each bingo cage (draws are done with replacement)

binprobs_a=binopdf((0:nballs)',nballs,pa);
binprobs_b=binopdf((0:nballs)',nballs,pb);

priors=(.01:.01:.99)';
binprobsupport=(0:nballs)';
nprior=size(priors,1);

posterior_a=zeros(nballs+1,nprior);  % posterior probability for outcome with 0 N balls in sample as a function of prior
xpriors=[];

for i=1:nprior;

   posterior_a(:,i)=binprobs_a*priors(i);
   posterior_a(:,i)=posterior_a(:,i)./(posterior_a(:,i)+binprobs_b*(1-priors(i)));
   xpriors=[xpriors; priors(i)*ones((nballs+1),1)];
end

x=[ones((nballs+1)*nprior,1) repmat(binprobsupport,nprior,1) xpriors];
y=icdf('norm',posterior_a(:),0,1);

% now regress y on x and see if we get a perfect fit

bet=inv(x'*x)*x'*y;
yhat=x*bet;
tssq=sum((y-mean(y)).^2);
pssq=sum((yhat-mean(y)).^2);
fprintf('Regression on inverse CDF-transformed posterior at a grid with %i values of the prior for all %i binomial realizations\n',nprior,nballs+1);
fprintf('Regression R-squared: %g and regression coefficients below\n',pssq/tssq);
bet

fprintf('Issue the Matlab command [y yhat] to see the actual inverse normal CDF transformed dependent value and the predicted value from the normal logistic regression\n');
fprintf('Issue the Matlab command [cdf(''norm'',y,0,1) cdf(''norm'',yhat,0,1)] to see the comparable values as the true prior and predicted prior from the normal logistic regression\n');
