% log_posterior_learning.m   uses various non-parametric and machine learning methods to approximate log(pi/(1-pi)), the
%                            log posterior odds ratio used to form a posterior probability of the run a sample of balls is
%                            drawn from in the Are People Bayesian? paper. The idea is that subjects may not be able to
%                            compute the log posterior odds in their head and only observe the prior probability pi of drawing
%                            from cage 1, so the question is how well can various machine learning and non-parametric regression
%                            methods do to approximate the log posterior odds in a parsimonious way?
%                            John Rust, Georgetown University, August 2023

x=[0:.001:1]';
nx=numel(x);
lpo=log(x./(1-x));
ind=find(~isinf(lpo));
x=x(ind);
lpo=lpo(ind);

x_train=rand(100,1);
%x_train=(0:.01:1)';
lpo_train=log(x_train./(1-x_train));

% polynomial regression prediction

%data=[x_train x_train.^2 x_train.^3 sqrt(x_train) 1./x_train 1./(1-x_train)];
data=[x_train x_train.^2 1./x_train 1./(1-x_train)];
bet=regress(lpo_train,data);

%reg_lpo=[x x.^2 x.^3 sqrt(x) 1./x 1./(1-x)]*bet;
reg_lpo=[x x.^2 1./x 1./(1-x)]*bet;


% local linear regression prediction

[llr_lpo]=llr(x,lpo_train,x_train);

% train neural network

net=feedforwardnet(10);
net=train(net,x_train',lpo_train');
predicted_net_lpo=net(x');



f1=figure(1);
clf(f1);
hold on;
plot(x,lpo,'b-','Linewidth',2);
plot(x,llr_lpo,'r-','Linewidth',2);
plot(x,predicted_net_lpo,'g-','Linewidth',2);
plot(x,reg_lpo,'k-','Linewidth',2);
title('Log posterior odds ratio');
legend('True log-posterior odds ratio',sprintf('Local linear regression: %i random training observations',numel(x_train)),...
sprintf('Neural network, relu activiation'),'Polynomial regression','Location','Southeast');
xlabel('Prior probability of cage 1');
xl=xlim;
axis([xl -10 10]);
ylabel('Log posterior odds ratio');
hold off;

fprintf('MSE for local linear regression: %g\n',sum((lpo-llr_lpo).^2));
fprintf('MSE for polynomial   regression: %g\n',sum((lpo-reg_lpo).^2));
fprintf('MSE for neural network         : %g\n',sum((lpo-predicted_net_lpo').^2));

x=(0:1:7);
llr_wisconsin=zeros(8,1);
llr_california=zeros(7,1);
llr_california(8)=NaN;
for i=0:7
    llr_wisconsin(i+1)=log(binopdf(i,7,.4)/binopdf(i,7,.6));
    if (i < 7)
    llr_california(i+1)=log(binopdf(i,6,2/3)/binopdf(i,6,1/2));
    end
end
f2=figure(2);
clf(f2);
hold on;
plot(x,llr_wisconsin,'b-','Linewidth',2);
plot(x,llr_california,'r-','Linewidth',2);
xlabel('Number of balls marked N');
ylabel('Log-likelihood ratio');
title('Log-likelihood ratios in the California and Wisconsin experiments');
legend('Wisconsin','California','Location','Northeast');
hold off;

