% DENPLOT.m: procedure to compute and plot nonparametric kernel density 
%            estimate of data vector */

function denplot(vname,tstring,argmin,argmax);

dat=evalin('base',vname);
%fprintf(1,'%s',name1);
x=argmin:1/1000:argmax; 
n=size(dat,1);
h=1.06/(n^(.2));
s=std(dat);
mu=mean(dat);
npden=zeros(size(x,2),1);
for i=1:size(x,2)
      npden(i,1)=sum(exp((-((x(1,i)-dat).*(x(1,i)-dat)))/(2*h*h*s*s)))/(s*sqrt(2*pi)*h*n);
end

plot(x,npden,'r-','Linewidth',2);
axis([argmin argmax 0 max(npden)]);
title(['Distribution of ' tstring]);
ylabel('Density');
xlabel('Score');
text(argmax-(argmax-argmin)/5,max(npden)*.9,['Mean    ' num2str(mu)]);
text(argmax-(argmax-argmin)/5,max(npden)*.85,['Median  ' num2str(median(dat))]);
text(argmax-(argmax-argmin)/5,max(npden)*.8,['Minimum ' num2str(min(dat))]);
text(argmax-(argmax-argmin)/5,max(npden)*.75,['Maximum ' num2str(max(dat))]);
text(argmax-(argmax-argmin)/5,max(npden)*.7,['Std dev ' num2str(s)]);
text(argmax-(argmax-argmin)/5,max(npden)*.65,['N       ' num2str(n)]);

