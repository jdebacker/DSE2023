% estimate_model.m  program to estimate various flexible reduced-form logit and probit models of subject choice in El-Gamal and Grether 1995 "Are People Bayesian?" data set
%                   this is a version of train_machine.m (i.e. estimate binary logit classification model by maximum likelihood)
%                   but now we are "training" the machine to behave like humans do, not usig the true data generating process in the experiment to
%                   train a machine how to behave according to Bayes Rule
%                   John Rust, Georgetown University, February, 2021

model='structural_logit';

%model='prior_as_log_odds';  % choices: 'prior_as_log_odds' or 'prior_linearly' 
%model='prior_linearly';
sample_type='all_pooled';  % choices: 'all_pooled' or 'all_individual'
errspec='logit';

multitype_method='ec';  % method for heterogeneity: 'ec' for Estimation-classification or 'hs' for Heckman-Singer finite mixture model
estimate_types='yes';
maxtypes=2;

if (strcmp(model,'llr_lpr'))
   truetheta=[0; -1; -1];
elseif (strcmp(model,'structural_logit'))
   truetheta=[.5; 0; -2; -2];
else
   truetheta=[6*(log(1/2)-log(1/3)); -log(2); 1];
end

options=optimoptions('fminunc','FunctionTolerance',1e-10,'Display','none','Algorithm','trust-region','SpecifyObjectiveGradient',true,'HessianFcn','objective');
%options=optimoptions('fminunc','FunctionTolerance',1e-10,'Display','iter','Algorithm','quasi-newton','SpecifyObjectiveGradient',true);

load datastruct;   % load the actual data and format into (ydata,xdata) 

[ydata,xdata]=learning_how_to_learn.prepare_data(datastruct,sample_type);

if (iscell(ydata));

   % in this case, when sample_type is `all_individual' ydata and xdata are cell arrays of dimension equal to the number of subjects in the datastruct,
   % allowing estimation of separate parameters for each subject separately

   % initialize cell arrays to store subject-specific log-likelihoods, parameters, and standard errors
   % then loop over each subject and estimate subject-specific parameters using the time-series dimension of the panel for each subject

   nsubjects=size(ydata,2);
   thetahat={};             % this will be a cell array containing the parameter estimates for a model estimated on a single subject's responses
   llf={}; 
   exitflag={};
   grad={};
   stderr={};
   thetahat_lr={};
   stderr_lr={};
   llf_lr={}; 
   output={};

   for subject=1:nsubjects

      subject_ydata=ydata{subject};
      subject_xdata=xdata{subject};

      sample_size=size(subject_ydata,1);
 
      if (subject==1)
         theta_start=zeros(3,1);
      else
         theta_start=subject_thetahat;
         theta_start=zeros(3,1);
      end

      fprintf('Estimating logit model by ML for subject %i\n',subject);

      if (strcmp(errspec,'logit'))
      tic;
      [subject_thetahat,subject_llf,subject_exitflag,subject_output,subject_grad,hessian]=...
      fminunc( @(theta) learning_how_to_learn.blogit(subject_ydata,subject_xdata,theta,model),theta_start,options);
        if (subject_exitflag <= 0)
          fminunc( @(theta) learning_how_to_learn.blogit(subject_ydata,subject_xdata,theta,model),subject_thetahat,options);
        end
      toc
      else
      tic;
      [subject_thetahat,subject_llf,subject_exitflag,subject_output,subject_grad,hessian]=...
      fminunc( @(theta) learning_how_to_learn.bprobit(subject_ydata,subject_xdata,theta,model),theta_start,options);
        if (subject_exitflag <= 0)
           fminunc( @(theta) learning_how_to_learn.bprobit(subject_ydata,subject_xdata,theta,model),subject_thetahat,options);
        end
      toc
      end

      fprintf('log-likelihood at optimum: %g\n',subject_llf);

      thetahat{subject}=subject_thetahat;
      llf{subject}=subject_llf;
      exitflag{subject}=subject_exitflag;
      grad{subject}=subject_grad; 
      stderr{subject}=sqrt(diag(inv(hessian)/sample_size));
      output{subject}=subject_output;

      fprintf('Estimating model by mnrfit for subject %i\n',subject);

      subject_ydata=1+subject_ydata;
      prior=subject_xdata(:,2);

      if (strcmp(model,'llr_lpr'))    % fix me: need to differentiate between wisconsin experiments that had cages with 10 balls in them
                                      % the code below only applies to the California experiments where each cage had 6 balls and also two
                                      % of the Wisconsin experiments where the same cage design as California was maintained
        pa=2/3;
        pb=1/2;
        ndraws=6;
        outcomes=(0:ndraws)';
        llr=log(binopdf(outcomes,ndraws,pa))-log(binopdf(outcomes,ndraws,pb));
        subject_xdata(:,1)=llr(subject_xdata(:,1)+1);  % recode the first column of xdata as the log-likeihood ratio log(f(n|A)/f(n|B)) not n
        subject_xdata(:,2)=log(prior)-log(1-prior);

      end


      if (strcmp(model,'prior_as_log_odds'))
         subject_xdata(:,2)=log(1-prior)-log(prior);  % prior log odds in last column of x matrix
      end

      tic;
        [b,dev,stats]=mnrfit(subject_xdata,subject_ydata);
      toc
      if (strcmp(errspec,'logit'))
      llf_lr{subject}=learning_how_to_learn.blogit(ydata{subject},xdata{subject},b,model);
      else
      llf_lr{subject}=learning_how_to_learn.bprobit(ydata{subject},xdata{subject},b,model);
      end
      fprintf('mnrfit result:  llf: %g\n',llf_lr{subject});

      thetahat_lr{subject}=b;
      stderr_lr{subject}=stats.se;

   end

   plot_fixed_effects;

elseif (~strcmp(model,'structural_logit'))
   
  % in this branch we just do a single estimation of the model for all subjects pooled and ydata,xdata are just ordinary arrays, not cell arrays 

   sample_size=size(ydata,1);

   if (strcmp(errspec,'logit'))
   tic;
   [thetahat,llf,exitflag,output,grad,hessian]=fminunc( @(theta) learning_how_to_learn.blogit(ydata,xdata,theta,model),0*truetheta,options);
   toc
   else
   tic;
   [thetahat,llf,exitflag,output,grad,hessian]=fminunc( @(theta) learning_how_to_learn.bprobit(ydata,xdata,theta,model),0*truetheta,options);
   toc
   end

   if (exitflag)
      fprintf('estimation completed using %i observations\n',size(ydata,1));
      if (strcmp(errspec,'logit'))
      fprintf('converged log-likelihood value %g  log-likelihood at Bayes Rule parameters %g\n',llf,learning_how_to_learn.blogit(ydata,xdata,truetheta,model));
      else
      fprintf('converged log-likelihood value %g  log-likelihood at Bayes Rule parameters %g\n',llf,learning_how_to_learn.bprobit(ydata,xdata,truetheta,model));
      end
   else
      fprintf('fminunc terminated with exitflag %i, algorithm may not have converged\n',exitflag);
   end

   stderr=sqrt(diag(inv(hessian)));

   fprintf('Estimated and Bayes Rule parameter vectors and std errors (last column)\n');
   [thetahat truetheta stderr]

   fprintf('gradient of log-likelihood with respect to parameters\n');
   grad

   ydata1=1+ydata;
   xdata1=xdata;
   prior=xdata1(:,2);

   if (strcmp(model,'llr_lpr'))    % fix me: need to differentiate between wisconsin experiments that had cages with 10 balls in them
                                 % the code below only applies to the California experiments where each cage had 6 balls and also two
                                 % of the Wisconsin experiments where the same cage design as California was maintained
    pa=2/3;
    pb=1/2;
    ndraws=6;
    outcomes=(0:ndraws)';
    llr=log(binopdf(outcomes,ndraws,pa))-log(binopdf(outcomes,ndraws,pb));
    xdata1(:,1)=llr(xdata1(:,1)+1);  % recode the first column of xdata as the log-likeihood ratio log(f(n|A)/f(n|B)) not n
    xdata1(:,2)=log(prior)-log(1-prior);

   end

   if (strcmp(model,'prior_as_log_odds'))
      xdata1(:,2)=log(1-prior)-log(prior);  % prior log odds in last column of x matrix
   end

   tic;
     [b,dev,stats]=mnrfit(xdata1,ydata1);
   toc
   if (strcmp(errspec,'logit'))
   fprintf('mnrfit result:  llf: %g\n',learning_how_to_learn.blogit(ydata,xdata,b,model));
   else
   fprintf('mnrfit result:  llf: %g\n',learning_how_to_learn.bprobit(ydata,xdata,b,model));
   end
   [b truetheta stats.se]

end


 if (strcmp(estimate_types,'yes') & ~strcmp(sample_type,'all_individual'))

 [ydata,xdata]=learning_how_to_learn.prepare_data(datastruct,'all_individual');
 options=optimoptions('fminunc','FunctionTolerance',1e-10,'Display','iter','Algorithm','quasi-newton','SpecifyObjectiveGradient',false,'MaxFunctionEvaluations',10000);

 % now estimate multi-type models, adding new types until a likelihood ratio test fails to reject a model with one fewer type in it

   ntypes=0;
   llr_threshold=.05;  % when a likelihood ratio test P-value exceeds this threshold, stop
   llr_pvalue=0;
   thetastart=[];

   while (llr_pvalue < llr_threshold | ntypes<=maxtypes)

       ntypes=ntypes+1;

       if (strcmp(multitype_method,'ec'))
          if (strcmp(model,'structural_logit'))
            df=4;
            load structural_thetahat; 
            if (ntypes == 1)
            thetastart=[thetastart; structural_thetahat];
            else
            thetastart=[thetahat; truetheta];
            end
fprintf('starting %i type search of ED with initial guess\n',ntypes);
thetastart'
            tic;
            [thetahat,llf,exitflag,output,grad,hessian]=fminunc( @(theta) learning_how_to_learn.ec_structural_logit(ydata,xdata,theta,ntypes),thetastart,options);
            toc
          else
            df=3;
            thetastart=[thetahat; zeros(3,1)];
            tic;
            [thetahat,llf,exitflag,output,grad,hessian]=fminunc( @(theta) learning_how_to_learn.ec_structural_logit(ydata,xdata,theta,ntypes,model),thetastart,options);
            toc
          end
       else
          df=4;
          thetastart=[0; thetahat; zeros(3,1)];
          tic;
          [thetahat,llf,exitflag,output,grad,hessian]=fminunc( @(theta) learning_how_to_learn.mixed_blogit(ydata,xdata,theta,ntypes,model),thetastart,options);
          toc
       end

       if (exitflag)
         fprintf('estimation of %i type model completed\n',ntypes);
         fprintf('converged log-likelihood value %g\n',llf);
         theta_hist{ntypes}=thetahat;
         stderr_hist{ntypes}=sqrt(diag(inv(hessian)));
         llf_hist{ntypes}=llf;
       else
         fprintf('fminunc terminated with exitflag %i, algorithm may not have converged\n',exitflag);
         break;
       end
      
       if (ntypes > 1) 
       llr_pvalue=cdf('chi2',2*(llf_hist{ntypes-1}-llf_hist{ntypes}),df,'upper');
       fprintf('Log-likelihood ratio test p-value for model with %i types relative to one with %i types: %g\n',ntypes,ntypes-1,llr_pvalue);
       end

       thetahat;

   end

   fprintf('\nTerminating the search for number of subject types: preferred model has %i types\n',ntypes-1);
   fprintf('Parameter estimates and std errors of the %i type model\n',ntypes-1)
   [theta_hist{ntypes-1} stderr_hist{ntypes-1}]

 end
