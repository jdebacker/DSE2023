% train_machine.m  program to "train the machine" (i.e. estimate binary logit classification model by maximum likelihood)
%                  John Rust, Georgetown University, August, 2023


dependent_variable='bayes_rule_classification';  % select either `true_classification' or else 'bayes_rule_classification' or 
                                                 % 'noisy_bayes_rule' where the former (the default return from generate_taining_data) 
                                                 % is the actual bingo cage that was selected to draw the sample  whereas 
                                                 % bayes_rule_classification is the cage that a perfect bayesian decision maker 
                                                 % would select after observing xdata, i.e. the number n of balls marked N and pi,
                                                 % the prior probability that cage A was drawn. This rule selects cage A if the true
                                                 % Bayesian posterior probability P(A|n,pi) (the posterior probability of A) is 1/2 or
                                                 % larger, and cage B otherwise.
                                                 % If noisy_bayes_rule is chosen the dependent variable is to select y=1 
                                                 % (cage A selected) with probability equal to the true posterior
                                                 % probability that cage A was selected as the cage from which the sample was drawn.
                                                 % Thus, this rule will be subject to random classification error in addition to the
                                                 % usual classification error under Bayes Rule (which has no additional noise in it)


decision_model='structural_blogit';   % 'structural_blogit' a structural binary logit model that depends on "subjective posterior beliefs" 
                                      % that the observed sample is drawn from urn A. This model has 4 parameters
                                      % theta(1) is sigma the scale parameter for extreme value shocks affecting the choice of cage
                                      % theta(2) is the constant term in the "subjective posterior probability" (for Bayes Rule, theta(2)=0)
                                      % theta(3) is the weight on the log likelihood ratio (for Bayes Rule, theta(3)=-1)
                                      % theta(4) is the weight on the log prior odds ratio (for Bayes Rule, theta(4)=-1)
                                      %
                                      % If theta is a 5x1 vector, then the structural logit model can be interpreted as a neural network
                                      % of depth 2 and width 1 with two transformed inputs (T(n),T(pi)) and one output (probability of 
                                      % selecting cage A) where T(n) is the log likelihood ratio T(n)=log(f(n|A,draws)/f(n|B,draws)) where 
                                      % f(n|A,draws) is the binomial probability of observing a total of n balls marked N out of draws IID
                                      % draws (i.e. with replacement) from cage A, and similarly for f(n|B,draws), and 
                                      % T(pi)=log(pi/(1-pi)) is the log prior odds ratio where pi is the prior probability of selecting cage A.
                                      % In this case the 5x1 parameter vector theta has the interpretation
                                      % theta(1) bias term in the output layer of the NN
                                      % theta(2) weight on the output of layer 1, the hidden unit input layer (binary logit probability)
                                      % theta(3) bias term in the input layer (theta(3)=0 for the first layer to return Bayesian posterior)
                                      % theta(4) weight on T(n), the log likelihood ratio input (theta(4)=-1 for Bayesian posterior)
                                      % theta(5) weight on T(pi), the log prior odds ratio input (theta(5)=-1 for Bayesian posterior)
                                      % 
                                      % Note that if prior_model input to structural_blogit is 'nn' then no transformation of the inputs is done
                                      % and then theta(4) is the weight on n and theta(5) is the weight on pi, and then the estimation is for a
                                      % traditional neural network of depth 2 and width 1.
         
prior_model='prior_linearly';
prior_model='llr_lpr';
                            % 'llr_lpr'  is the logistic regression specification of the model using the log of the 
                            %            posterior odds ratio, which breaks into two pieces, the log-likelihood ratio (llr) 
                            %            and the log-prior-odds-ratio (lpr). We also add a constant but notice Bayes rule posterior
                            %            is the special case where the coefficient vector is (0,-1,-1) where both llr and lpr 
                            %            are given equal weight in the log-posterior odds ratio  and the "bias term" is zero.
                            %
                            % 'prior_as_log_odds' nests true Bayes rule as a special case for the truetheta parameter vector below
                            %
                            % 'prior_linearly'  does not nest true Bayes Rule as a special case, and thus constitutes a 
                            %                   misspecified model that can can only approximate the Bayesian posterior belief.
                            %                   The parameters for this specification can be regarded as the bias and "input weights"
                            %                   of a simple neural network of depth 2 and width 1 (2 inputs and 1 output) with the
                            %                   logistic activation or squashing function.
                            % 
                            % 'nn'  use untransformed inputs in the first layer of structural_blogit, i.e. (n,pi) instead of (T(n),T(pi))
                            %       where T(n) is log likelihood ratio and T(pi) is the log prior odds ratio

errspec='logit';           % specification for the error term: 'probit' or 'logit'      

pa=2/3;
pb=1/2;
nballs=6;

training_sample_size=20;

if (strcmp(decision_model,'structural_blogit'))

   truetheta=[0; 0; -1; -1];

elseif (strcmp(decision_model,'llr_lpr'))  % in this specification xdata has first column equal to log(f(n|A)/f(n|B)) 
                                           % and 2nd column equal to log(pa/(1-pa)) where pa is the prior that cage A was used
   truetheta=[0; -1; -1];

else                                       % in this specification xdata has first column equal to n and 2nd column equal to prior

   truetheta=[6*(log(1/2)-log(1/3)); -log(2); 1];

end

options=optimoptions('fminunc','FunctionTolerance',1e-10,'Display','iter','Algorithm','trust-region','SpecifyObjectiveGradient',true,'HessianFcn','objective');
%options=optimoptions('fminunc','FunctionTolerance',1e-10,'Display','iter','Algorithm','quasi-newton','SpecifyObjectiveGradient',true);

if (~exist('ydata'))
  fprintf('Generating new training sample with %i observations\n',training_sample_size);
  [ydata,xdata]=learning_how_to_learn.generate_training_data(training_sample_size,pa,pb,nballs,dependent_variable);
end



if (strcmp(decision_model,'structural_blogit'))
  tic;
  starttheta=truetheta;
  starttheta(1)=1;
  %starttheta=randn(5,1);
  if (exist('thetahat'))
     starttheta=thetahat;
  end
  [thetahat,llf,exitflag,output,grad,hessian]=...
  fminunc( @(theta) learning_how_to_learn.structural_blogit(ydata,xdata,pa,pb,nballs,theta,prior_model),starttheta,options);
  toc
elseif (strcmp(decision_model,'logit'))
  tic;
  [thetahat,llf,exitflag,output,grad,hessian]=...
  fminunc( @(theta) learning_how_to_learn.blogit(ydata,xdata,pa,pb,nballs,theta,prior_model),0*truetheta,options);
  toc
else
  tic;
  [thetahat,llf,exitflag,output,grad,hessian]=...
  fminunc( @(theta) learning_how_to_learn.bprobit(ydata,xdata,pa,pb,nballs,theta,prior_model),0*truetheta,options);
  toc
end

if (exitflag)
  fprintf('training of learning machine has completed using %i training instances (i.e. observations)\n',training_sample_size);
  if (strcmp(decision_model,'structural_blogit'))
    fprintf('converged log-likelihood value %g negative log-likelihood per observation: %g\n',-llf,llf/numel(ydata));
  elseif (strcmp(decision_model,'logit'))
    llft=learning_how_to_learn.blogit(ydata,xdata,pa,pb,nballs,truetheta,prior_model);
    fprintf('converged log-likelihood value %g  log-likelihood at true parameters %g likelihood ratio test P-value: %g\n',...
    -llf,-llft,chi2cdf(2*(llft-llf),numel(truetheta),'upper'));
  else
    llft=learning_how_to_learn.bprobit(ydata,xdata,pa,pb,nballs,truetheta,prior_model);
    fprintf('converged log-likelihood value %g  log-likelihood at true parameters %g likelihood ratio test P-value: %g\n',...
    -llf,-llft,chi2cdf(2*(llft-llf),numel(truetheta),'upper'));
 end
else
  fprintf('fminunc terminated with exitflag %i, algorithm may not have converged\n',exitflag);
end

stderr=sqrt(diag(inv(hessian)));
if (strcmp(decision_model,'structural_blogit'))
fprintf('\nEstimated coefficients by maximum likelihood using the likelihood function in learning_how_to_learn.structural_blogit\n');
fprintf('and Matlab fminunc command.\n');
end
fprintf('Training sample size: %i\n',training_sample_size);
if (isreal(stderr))
 fprintf('Estimated and true parameter vectors and std errors (last column)\n');
 if (numel(thetahat) == 5)
   [thetahat [inf; inf; 0; -1; -1] stderr]
 else
   [thetahat truetheta stderr]
 end
else
  fprintf('Estimated and true parameter vectors\n');
  if (numel(thetahat) == numel(truetheta))
  [thetahat truetheta]
  else
  thetahat
  end
end

fprintf('gradient of log-likelihood with respect to parameters\n');
grad

fprintf('Now train machine using Matlab Deep Learning Toolbox\n');

fprintf('Step 1: use patternnet command to configure a 2 hidden layer network with 2 inputs and 1 output with sigmoid activation\n');
net=patternnet(1); 

% configure patternnet for logistic squashing functions and not to pre-scale the data
  net.layers{1}.transferFcn='logsig';
  net.layers{2}.transferFcn='logsig';
  net.Inputs{1}.processFcns={'fixunknowns'};
%view(net);         

fprintf('Step 2: train the network using the simulated training data using the train command\n');
net=train(net,xdata',ydata');

fprintf('Step 3: use the trained network to predict probabilities of choosing cage A at the training data points\n');
nn_prediction=net(xdata')';

fprintf('Step 4:  use the predicted probabilities of choosing cage A to calculate performance (crossentropy, aka negative log likelihood)\n');
nll=perform(net,ydata',nn_prediction');

fprintf('Step 5: collect parameters of the trained neural network and compare to my own maximum likelihood estimates of the net parameters\n');
layer1_params=[net.b{1}; net.IW{1}'];
layer2_params=[net.b{2}; net.LW{2}];

% calculate the predicted probabilities of choosing cage A in the data with the converged parameters for my NN

[llf,dllf,hllf,im,cpa]=learning_how_to_learn.structural_blogit(ydata,xdata,pa,pb,nballs,thetahat,prior_model);
true_bayes_posterior_training_data=learning_how_to_learn.subjective_posterior_prob(xdata,pa,pb,nballs,[0;-1;-1],'llr_lpr');

if (numel(thetahat) == 5)

fprintf('My NN point estimates    Matlab NN point estimates\n');
[thetahat [layer2_params; layer1_params]]
fprintf('My NN negative LL: %g\n',llf);
fprintf('Matlab NN crossentropy loss: %g\n',nll*training_sample_size);
subjective_posterior_training_data=learning_how_to_learn.subjective_posterior_prob(xdata,pa,pb,nballs,thetahat(3:5),prior_model);

fprintf('training data: cage A=1  N   prior   true posterior A  my NN layer 1 output  my NN layer 2 output Matlab NN output\n');
[ydata xdata true_bayes_posterior_training_data subjective_posterior_training_data cpa nn_prediction]

else

fprintf('My structural logit parameter estimates    Matlab NN point estimates\n');
thetatmp=thetahat;
thetatmp(2)=1/thetatmp(2);
[[0; thetatmp] [layer2_params; layer1_params]]
subjective_posterior_training_data=learning_how_to_learn.subjective_posterior_prob(xdata,pa,pb,nballs,thetahat(2:4),prior_model);

fprintf('My NN negative LL: %g\n',llf);
fprintf('Matlab NN crossentropy loss: %g\n',nll*training_sample_size);
fprintf('training data: cage A=1  N  prior  true posterior A  subjective posterior  structural logit ccp A  Matlab NN prob\n');
[ydata xdata true_bayes_posterior_training_data subjective_posterior_training_data cpa nn_prediction]

end

% use the predicted choice probabilites to create predictions of the correct cage in the training data set

my_nn_prediction=(cpa>.5);
matlab_nn_prediction=(nn_prediction>.5);

if (numel(thetahat) == 5)
fprintf('In-sample performance of the trained neural network\n');
else
fprintf('In-sample performance of the trained structural model\n');
end
fprintf('percent correctly predicted:     My nn: %g\n',100*sum(ydata==my_nn_prediction)/numel(ydata));
fprintf('percent correctly predicted: Matlab nn: %g\n',100*sum(ydata==matlab_nn_prediction)/numel(ydata));


% do plots to visually compare the data to the in-sample and out-of-sample model predictions

[stbp,sind]=sort(true_bayes_posterior_training_data);
ssp=subjective_posterior_training_data(sind);

stbp=[0; stbp; 1];
ssp=[NaN; ssp; NaN];
 
f1=figure(1);
clf(f1);
hold on;
plot(stbp,stbp,'k-','Linewidth',2);
plot(stbp,ssp,'r-','Linewidth',2);
xlabel('True posterior probability of Cage A');
ylabel('Inferred and true posterior probability of Cage A');
axis('square');
legend('True Bayesian posterior prob of cage A','Inferred posterior prob of cage A','Location','Southeast');
title(sprintf('Inferred vs true Bayesian posterior probabilities from %i training observations',training_sample_size));
hold off;


% now do an out of sample predictive test of the performance of the two nets

evaluation_sample_size=200;
[ev_ydata,ev_xdata]=learning_how_to_learn.generate_training_data(evaluation_sample_size,pa,pb,nballs,dependent_variable);

matlab_nn_out_of_sample_predicted_ccps=net(ev_xdata')';
matlab_ev_nll=perform(net,ev_ydata',matlab_nn_out_of_sample_predicted_ccps');
[my_ev_nll,ev_dllf,ev_hllf,ev_im,my_nn_out_of_sample_predicted_ccps]=learning_how_to_learn.structural_blogit(ev_ydata,ev_xdata,pa,pb,nballs,thetahat,prior_model);

fprintf('Comparison of performance in out of sample predictive test using %i randomly generated evaluation observations\n',evaluation_sample_size);
fprintf('out of sample likelihood:     my NN:  %g\n',my_ev_nll/evaluation_sample_size);
fprintf('out of sample likelihood: Matlab NN:  %g\n',matlab_ev_nll);
my_ev_nn_prediction=(my_nn_out_of_sample_predicted_ccps>.5);
matlab_ev_nn_prediction=(matlab_nn_out_of_sample_predicted_ccps>.5);
fprintf('percent correctly predicted:     My nn: %g\n',100*sum(ev_ydata==my_ev_nn_prediction)/evaluation_sample_size);
fprintf('percent correctly predicted: Matlab nn: %g\n',100*sum(ev_ydata==matlab_ev_nn_prediction)/evaluation_sample_size);
reply = input('Print out the evaluation data and compare my NN ccps and Matlab NN ccps? Y/N (1/0) [0]:','s');
       if isempty(reply)
          reply = '0';
       end
if (strcmp(reply,'1'))
[ev_ydata ev_xdata my_nn_out_of_sample_predicted_ccps matlab_nn_out_of_sample_predicted_ccps]
end

% now compare to using Matlab's built-in logistic regression function, mnrfit, to estimate the model

if (~strcmp(decision_model,'structural_blogit'))

ydata1=1+ydata;
xdata1=xdata;
prior=xdata1(:,2);

if (strcmp(model,'llr_lpr'))    % fix me: need to differentiate between wisconsin experiments that had cages with 10 balls in them
                                 % the code below only applies to the California experiments where each cage had 6 balls and also two
                                 % of the Wisconsin experiments where the same cage design as California was maintained
    outcomes=(0:ndraws)';
    llr=log(binopdf(outcomes,ndraws,pa))-log(binopdf(outcomes,ndraws,pb));
    xdata1(:,1)=llr(xdata1(:,1)+1);  % recode the first column of xdata as the log-likeihood ratio log(f(n|A)/f(n|B)) not n
    xdata1(:,2)=log(prior)-log(1-prior);

end

if (strcmp(prior_model,'prior_as_log_odds'))
xdata1(:,2)=log(1-prior)-log(prior);  % prior log odds in last column of x matrix
end

fprintf('Estimated coefficients by logistic regression and Matlab mnrfit command\n');
fprintf('Estimated and true parameter vectors and std errors (last column)\n');
tic;
[b,dev,stats]=mnrfit(xdata1,ydata1);
toc
if (strcmp(decision_model,'logit'))
  fprintf('mnrfit result:  llf: %g\n',learning_how_to_learn.blogit(ydata,xdata,pa,pb,nballs,b,prior_model));
else
  fprintf('mnrfit result:  llf: %g\n',learning_how_to_learn.bprobit(ydata,xdata,pa,pb,nballs,b,prior_model));
end
[b truetheta stats.se]

end
