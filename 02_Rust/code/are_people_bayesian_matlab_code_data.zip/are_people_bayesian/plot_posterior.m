% plot_posterior.m plots the posterior probabilities for drawing from Bingo cage A as a funtion of prior for all outcomes (0,...,6)
%                  based on 1995 JASA paper of El-Gamal and Grether, "Are People Bayesian? Uncovering Behavioral Strategies"

% temporarily fixed parameters relevant for the California experiments. Later adjust these for values relevant to Wisconsin experiments

pa=2/3;  % probability of drawing a ball marked N from bingo cage A (4 N balls, 2 G balls)
pb=1/2;  % probability of drawing a ball marked N from bingo cage B (3 N balls, 3 G balls)
nballs=6;  % number of balls in each bingo cage (draws are done with replacement)

% these parameters you can change and play with to understand the model and estimation

dependent_variable='true_classification';

sample_type='all_pooled_california';  % choices: 'all_pooled' or 'all_individual'
model='prior_linearly';  % possible model types currently, prior_linearly  prior_as_log_odds and llr_lpr
%model='llr_lpr';

training_sample_size=1000;


% Rest of the code does some calculations and plots some graphs

binprobs_a=binopdf((0:nballs),nballs,pa);
binprobs_b=binopdf((0:nballs),nballs,pb);

prior=(0:.01:1)';
nprior=size(prior,1);

posterior_a=zeros(nprior,nballs+1);  % posterior probability for outcome with 0 N balls in sample as a function of prior
subjective_posterior_a=zeros(nprior,nballs+1); 

for i=1:nprior;

   posterior_a(i,:)=binprobs_a*prior(i);
   posterior_a(i,:)=posterior_a(i,:)./(posterior_a(i,:)+binprobs_b*(1-prior(i)));

end

if (strcmp(model,'llr_lpr'))  % in this specification xdata has first column equal to log(f(n|A)/f(n|B)) and 2nd column equal to log(pa/(1-pa)) where pa is the prior that cage A was used
   truetheta=[0; -1; -1];
else   % in this specification xdata has first column equal to n and 2nd column equal to prior
   truetheta=[6*(log(1/2)-log(1/3)); -log(2); 1];
end

options=optimoptions('fminunc','FunctionTolerance',1e-10,'Display','iter','Algorithm','trust-region','SpecifyObjectiveGradient',true,'HessianFcn','objective');
options=optimoptions('fminunc','FunctionTolerance',1e-10,'Display','iter','Algorithm','quasi-newton','SpecifyObjectiveGradient',false);

[ydata,xdata]=learning_how_to_learn.generate_training_data(training_sample_size,pa,pb,nballs,dependent_variable);

tic;
[trainedthetahat,llf,exitflag,output,grad,hessian]=fminunc( @(theta) learning_how_to_learn.blogit(ydata,xdata,pa,pb,nballs,theta,model),0*truetheta,options);
toc

if (exitflag)
fprintf('training of learning machine has completed using %i training instances (i.e. observations)\n',training_sample_size);
fprintf('converged log-likelihood value %g  log-likelihood at true parameters %g\n',llf,learning_how_to_learn.blogit(ydata,xdata,pa,pb,nballs,truetheta,model));
else
  fprintf('fminunc terminated with exitflag %i, algorithm may not have converged\n',exitflag);
end

trained_stderr=sqrt(diag(inv(hessian)/training_sample_size));

fprintf('\nEstimated coefficients by maximum likelihood using the likelihood function in learning_how_to_learn.logit and Matlab fminunc command\n');
fprintf('Estimated and true parameter vectors and std errors (last column)\n');
[trainedthetahat truetheta trained_stderr]


trained_posterior_a=zeros(size(prior,1),nballs+1);
for i=0:nballs;
    trained_posterior_a(:,i+1)=learning_how_to_learn.subjective_posterior_prob([i*ones(101,1) prior],pa,pa,nballs,trainedthetahat,model);
end;
trained_model_cutoffs=zeros(nballs,1);
for i=0:nballs
   ind=min(find(trained_posterior_a(:,nballs+1-i)>=1/2));
   if (~isempty(ind))
   trained_model_cutoffs(i+1)=prior(ind-1)+((1/2-trained_posterior_a(ind,nballs+1-i))/(trained_posterior_a(ind,nballs+1-i)-trained_posterior_a(ind-1,nballs+1-i)))*(prior(ind)-prior(ind-1));
   end
   %fprintf('prior(ind-1)=%g  cutoff %g  prior(ind)=%g\n',prior(ind-1),scutoffs(i+1),prior(ind));
end


figure(1);
clf
hold on;
plot(prior,posterior_a,'Linewidth',2);
plot(prior,.5*ones(nprior,1),'k:','Linewidth',2);
title('True posterior probabilities of drawing outcomes, by prior probability');
ylabel(sprintf('Posterior probability P(A|n,\\pi_A)'));
xlabel(sprintf('Prior probability \\pi_A'));
legend(sprintf('P(A|0,\\pi_A)'),sprintf('P(A|1,\\pi_A)'),sprintf('P(A|2,\\pi_A)'),sprintf('P(A|3,\\pi_A)'),...
sprintf('P(A|4,\\pi_A)'),sprintf('P(A|5,\\pi_A)'),sprintf('P(A|6,\\pi_A)'),'Location','Northwest');
axis square;
hold off;

figure(2);
clf
hold on;
plot(prior,trained_posterior_a,'Linewidth',2);
plot(prior,.5*ones(nprior,1),'k:','Linewidth',2);
title('Trained posterior probabilities of drawing outcomes, by prior probability');
ylabel(sprintf('Posterior probability P(A|n,\\pi_A)'));
xlabel(sprintf('Prior probability \\pi_A'));
legend(sprintf('P(A|0,\\pi_A)'),sprintf('P(A|1,\\pi_A)'),sprintf('P(A|2,\\pi_A)'),sprintf('P(A|3,\\pi_A)'),...
sprintf('P(A|4,\\pi_A)'),sprintf('P(A|5,\\pi_A)'),sprintf('P(A|6,\\pi_A)'),'Location','Northwest');
axis square;
hold off;


cutoffs=zeros(nballs+1,1);
for i=1:nballs+1
  r=binprobs_a(nballs+2-i)/binprobs_b(nballs+2-i);
  cutoffs(i)=1/(1+r);
end

figure(3);
clf
hold on;
line([0 cutoffs(1)],[6 6],'Linewidth',2,'Color','k');
line([cutoffs(1) cutoffs(1)],[6 5],'Linewidth',2,'Color','k');
line([cutoffs(1) cutoffs(2)],[5 5],'Linewidth',2,'Color','k');
line([cutoffs(2) cutoffs(2)],[5 4],'Linewidth',2,'Color','k');
line([cutoffs(2) cutoffs(3)],[4 4],'Linewidth',2,'Color','k');
line([cutoffs(3) cutoffs(3)],[4 3],'Linewidth',2,'Color','k');

line([cutoffs(3) cutoffs(4)],[3 3],'Linewidth',2,'Color','k');
line([cutoffs(4) cutoffs(4)],[3 2],'Linewidth',2,'Color','k');

line([cutoffs(4) cutoffs(5)],[2 2],'Linewidth',2,'Color','k');
line([cutoffs(5) cutoffs(5)],[2 1],'Linewidth',2,'Color','k');

line([cutoffs(5) cutoffs(6)],[1 1],'Linewidth',2,'Color','k');
line([cutoffs(6) cutoffs(6)],[1 0],'Linewidth',2,'Color','k');

line([cutoffs(6) cutoffs(7)],[0 0],'Linewidth',2,'Color','k');
line([cutoffs(7) cutoffs(7)],[0 -1],'Linewidth',2,'Color','k');

line([cutoffs(7) 1],[-1 -1],'Linewidth',2,'Color','k');

text(.6,4,'Choose A');
text(.1,2,'Choose B');

title('Decision regions implied by Bayes Rule');
xlabel(sprintf('Prior probability \\pi_A'));
ylabel(sprintf('Number of balls marked N, n'));
hold off;


figure(4);
clf
hold on;
line([0 cutoffs(1)],[6 6],'Linewidth',1,'Color','k');
line([cutoffs(1) cutoffs(1)],[6 5],'Linewidth',1,'Color','k');
line([cutoffs(1) cutoffs(2)],[5 5],'Linewidth',1,'Color','k');
line([cutoffs(2) cutoffs(2)],[5 4],'Linewidth',1,'Color','k');
line([cutoffs(2) cutoffs(3)],[4 4],'Linewidth',1,'Color','k');
line([cutoffs(3) cutoffs(3)],[4 3],'Linewidth',1,'Color','k');

line([cutoffs(3) cutoffs(4)],[3 3],'Linewidth',1,'Color','k');
line([cutoffs(4) cutoffs(4)],[3 2],'Linewidth',1,'Color','k');

line([cutoffs(4) cutoffs(5)],[2 2],'Linewidth',1,'Color','k');
line([cutoffs(5) cutoffs(5)],[2 1],'Linewidth',1,'Color','k');

line([cutoffs(5) cutoffs(6)],[1 1],'Linewidth',1,'Color','k');
line([cutoffs(6) cutoffs(6)],[1 0],'Linewidth',1,'Color','k');

line([cutoffs(6) cutoffs(7)],[0 0],'Linewidth',1,'Color','k');
line([cutoffs(7) cutoffs(7)],[0 -1],'Linewidth',1,'Color','k');

line([cutoffs(7) 1],[-1 -1],'Linewidth',1,'Color','k');


b=find(ydata==0);
bpriors=xdata(b,2);
bdraws=xdata(b,1);
scatter(bpriors,bdraws,10,'MarkerEdgeColor','b','MarkerFaceColor','b');
a=find(ydata==1);
apriors=xdata(a,2);
adraws=xdata(a,1);
scatter(apriors,adraws,10,'MarkerEdgeColor','r','MarkerFaceColor','r');

title('Decision regions implied by Bayes Rule');
xlabel(sprintf('Prior probability \\pi_A'));
ylabel(sprintf('Number of balls marked N, n'));
hold off;



% calculate predicted bingo cage using Bayes rule and compare to actual cage in ydata

posterior_a_data=zeros(training_sample_size,nballs+1);
predicted_y=zeros(training_sample_size,1);
posterior_a_trained=learning_how_to_learn.subjective_posterior_prob(xdata,pa,pb,nballs,trainedthetahat,model);
predicted_y_trained=zeros(training_sample_size,1);

for i=1:training_sample_size

   posterior_a_data(i,:)=binprobs_a*xdata(i,2);
   posterior_a_data(i,:)=posterior_a_data(i,:)./(posterior_a_data(i,:)+binprobs_b*(1-xdata(i,2)));
   predicted_y(i)=(posterior_a_data(i,xdata(i,1)+1) >= .5);
   predicted_y_trained(i)=(posterior_a_trained(i) >= .5);

end

svmmodel=fitcsvm(xdata,ydata,'holdout',0.2);
[predicted_y_svm,score] = predict(svmmodel.Trained{1},xdata);

%[ydata predicted_y predicted_y_svm]
fprintf('Results for training sample of size %i\n',training_sample_size);
fprintf('prediction error rate from true Bayes rule classifier   : %g\n',sum(ydata ~= predicted_y)/training_sample_size);
fprintf('prediction error rate from trained Bayes rule classifier: %g\n',sum(ydata ~= predicted_y_trained)/training_sample_size);
fprintf('prediction error rate from trained SVM classifier       : %g\n',sum(ydata ~= predicted_y_svm)/training_sample_size);


% estimate model on the actual data (homogeneous model) and plot subjective posterior probabilities
if (~exist('datastruct'))
   load('datastruct');
end


[ydata,xdata]=learning_how_to_learn.prepare_data(datastruct,sample_type);

if (iscell(ydata))
   fprintf('Sorry cannot run the empirical graphs using subject-specific choice models, i.e. with model=%s\n',model);
else
tic;
[thetahat,llf,exitflag,output,grad,hessian]=fminunc( @(theta) learning_how_to_learn.blogit(ydata,xdata,pa,pb,nballs,theta,model),0*truetheta,options);
toc

estimated_stderr=sqrt(diag(inv(hessian)/size(ydata,1)));

subjective_posterior_a=zeros(size(prior,1),nballs+1);
for i=0:nballs;
    subjective_posterior_a(:,i+1)=learning_how_to_learn.subjective_posterior_prob([i*ones(101,1) prior],pa,pb,nballs,thetahat,model);
end;

% calculate the "subjective cutoffs" (scutoffs) where the subjective_posterior_a first equals 1/2, by interpolation
scutoffs=zeros(nballs,1);
for i=0:nballs
   ind=min(find(subjective_posterior_a(:,nballs+1-i)>=1/2));
   if (~isempty(ind))
   scutoffs(i+1)=prior(ind-1)+((1/2-subjective_posterior_a(ind,nballs+1-i))/(subjective_posterior_a(ind,nballs+1-i)-subjective_posterior_a(ind-1,nballs+1-i)))*(prior(ind)-prior(ind-1));
   end
   %fprintf('prior(ind-1)=%g  cutoff %g  prior(ind)=%g\n',prior(ind-1),scutoffs(i+1),prior(ind));
end

figure(5);
clf
hold on;
plot(prior,subjective_posterior_a,'Linewidth',2);
plot(prior,.5*ones(nprior,1),'k:','Linewidth',2);
title('Subjective posterior probabilities of drawing outcomes, by prior probability');
ylabel(sprintf('Subjective (binary logit) Posterior probability P(A|n,\\pi_A)'));
xlabel(sprintf('Prior probability \\pi_A'));
legend(sprintf('P(A|0,\\pi_A)'),sprintf('P(A|1,\\pi_A)'),sprintf('P(A|2,\\pi_A)'),sprintf('P(A|3,\\pi_A)'),...
sprintf('P(A|4,\\pi_A)'),sprintf('P(A|5,\\pi_A)'),sprintf('P(A|6,\\pi_A)'),'Location','Northwest');
axis square;
hold off;

figure(6);
clf
hold on;
line([0 cutoffs(1)],[6 6],'Linewidth',1,'Color','k');
line([cutoffs(1) cutoffs(1)],[6 5],'Linewidth',1,'Color','k');
line([cutoffs(1) cutoffs(2)],[5 5],'Linewidth',1,'Color','k');
line([cutoffs(2) cutoffs(2)],[5 4],'Linewidth',1,'Color','k');
line([cutoffs(2) cutoffs(3)],[4 4],'Linewidth',1,'Color','k');
line([cutoffs(3) cutoffs(3)],[4 3],'Linewidth',1,'Color','k');
line([cutoffs(3) cutoffs(4)],[3 3],'Linewidth',1,'Color','k');
line([cutoffs(4) cutoffs(4)],[3 2],'Linewidth',1,'Color','k');
line([cutoffs(4) cutoffs(5)],[2 2],'Linewidth',1,'Color','k');
line([cutoffs(5) cutoffs(5)],[2 1],'Linewidth',1,'Color','k');
line([cutoffs(5) cutoffs(6)],[1 1],'Linewidth',1,'Color','k');
line([cutoffs(6) cutoffs(6)],[1 0],'Linewidth',1,'Color','k');
line([cutoffs(6) cutoffs(7)],[0 0],'Linewidth',1,'Color','k');
line([cutoffs(7) cutoffs(7)],[0 -1],'Linewidth',1,'Color','k');
line([cutoffs(7) 1],[-1 -1],'Linewidth',1,'Color','k');

line([0 scutoffs(1)],[6 6],'Linewidth',1,'Color','k','Linestyle',':');
line([scutoffs(1) scutoffs(1)],[6 5],'Linewidth',1,'Color','k','Linestyle',':');
line([scutoffs(1) scutoffs(2)],[5 5],'Linewidth',1,'Color','k','Linestyle',':');
line([scutoffs(2) scutoffs(2)],[5 4],'Linewidth',1,'Color','k','Linestyle',':');
line([scutoffs(2) scutoffs(3)],[4 4],'Linewidth',1,'Color','k','Linestyle',':');
line([scutoffs(3) scutoffs(3)],[4 3],'Linewidth',1,'Color','k','Linestyle',':');
line([scutoffs(3) scutoffs(4)],[3 3],'Linewidth',1,'Color','k','Linestyle',':');
line([scutoffs(4) scutoffs(4)],[3 2],'Linewidth',1,'Color','k','Linestyle',':');
line([scutoffs(4) scutoffs(5)],[2 2],'Linewidth',1,'Color','k','Linestyle',':');
line([scutoffs(5) scutoffs(5)],[2 1],'Linewidth',1,'Color','k','Linestyle',':');
line([scutoffs(5) scutoffs(6)],[1 1],'Linewidth',1,'Color','k','Linestyle',':');
line([scutoffs(6) scutoffs(6)],[1 0],'Linewidth',1,'Color','k','Linestyle',':');
if (size(scutoffs,1)>6)
line([scutoffs(6) scutoffs(7)],[0 0],'Linewidth',1,'Color','k','Linestyle',':');
line([scutoffs(7) scutoffs(7)],[0 -1],'Linewidth',1,'Color','k','Linestyle',':');
line([scutoffs(7) 1],[-1 -1],'Linewidth',1,'Color','k','Linestyle',':');
end
red=[1,0,0];
blue=[0,0,1];
color=1/2*red+1/2*blue;
ndraws=(0:nballs)';
npriors=[1/3; 1/2; 2/3];
total_nobs=0;
averr=.3727;
for nb=1:nballs+1
 for np=1:3
    frac=mean(ydata(find(xdata(:,1)==ndraws(nb) & abs(xdata(:,2)-npriors(np))<.01)));
    nobs=sum(xdata(:,1)==ndraws(nb) & abs(xdata(:,2)-npriors(np))<.01);
    total_nobs=total_nobs+nobs;
    if (nobs)
    color=frac*red+(1-frac)*blue;
    %fprintf('balls %i prior %g frac %g nobs=%i\n',ndraws(nb),npriors(np),frac,nobs);
    ms=1+40*(nobs/600);
    plot(npriors(np),ndraws(nb),'o','Markersize',ms,'MarkerEdgeColor',color,'MarkerFaceColor',color);
    end
 end
end
fprintf('total number of observations: %i\n',total_nobs);

title('Decision regions: Bayes Posterior vs Subjective Posterior');
xlabel(sprintf('Prior probability \\pi_A'));
ylabel(sprintf('Number of balls marked N, n'));
hold off;

end % end to an if statement making sure that subject data is not subjecti-specific, i.e. that ydata and xdata are not cell arrays

% plot last figure to show expected conditional loss from using Bayes Rule as the decision rule

figure(7);
clf;
x=(0:.01:1)';
sx=size(x,1);
y=zeros(sx,1);
y=x.*(x<=.5)+(1-x).*(x>.5);
plot(x,y,'b-','Linewidth',2);
xlabel(sprintf('Posterior probability P(A|n,\\pi_A)'));
ylabel(sprintf('Expected loss (prediction error) given (n,\\pi_A)'));
title(sprintf('Expected Loss (Prediction Error) from Bayes Rule given (n,\\pi_A)'));

fprintf('Comparing estimated theta coefficients for the training sample of %i observations\n',training_sample_size);
fprintf('with the empirical estimates of theta using the human subject data with %i observations\n',size(ydata,1));
fprintf('True theta, trained theta (artificial data), estimated theta (subject data)\n');
[truetheta trainedthetahat thetahat]
fprintf('Std error of the trained and estimated theta parameters\n');
[trained_stderr estimated_stderr]
